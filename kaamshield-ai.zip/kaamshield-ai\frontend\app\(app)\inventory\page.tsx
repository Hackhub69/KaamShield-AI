"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { api, inr } from "@/lib/api";
import { Badge, EmptyState, ErrorBanner, LoadingState, SuccessBanner } from "@/components/ui";
import type { InventoryRow } from "@/lib/types";

const emptyForm = {
  sku: "",
  name: "",
  category: "",
  quantity_on_hand: "0",
  reorder_threshold: "0",
  safety_stock: "0",
  avg_daily_demand: "0",
  unit_cost: "0",
  selling_price: "0",
  lead_time_days: "7",
};

export default function InventoryPage() {
  const [rows, setRows] = useState<InventoryRow[]>([]);
  const [q, setQ] = useState("");
  const [risk, setRisk] = useState("");
  const [sort, setSort] = useState<"sku" | "risk" | "stockout">("risk");
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const data = await api<InventoryRow[]>(`/api/inventory${q || risk ? `?${new URLSearchParams({ ...(q ? { q } : {}), ...(risk ? { risk } : {}) })}` : ""}`);
      setRows(data);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load inventory");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const sorted = useMemo(() => {
    const copy = [...rows];
    const rank: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3, unknown: 4 };
    copy.sort((a, b) => {
      if (sort === "sku") return a.sku.localeCompare(b.sku);
      if (sort === "stockout") return (a.expected_stockout_date || "9999").localeCompare(b.expected_stockout_date || "9999");
      return (rank[a.risk_level] ?? 9) - (rank[b.risk_level] ?? 9);
    });
    return copy;
  }, [rows, sort]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setOk("");
    try {
      const payload = {
        sku: form.sku,
        name: form.name,
        category: form.category,
        quantity_on_hand: Number(form.quantity_on_hand),
        reorder_threshold: Number(form.reorder_threshold),
        safety_stock: Number(form.safety_stock),
        avg_daily_demand: Number(form.avg_daily_demand),
        unit_cost: Number(form.unit_cost),
        selling_price: Number(form.selling_price),
        lead_time_days: Number(form.lead_time_days),
      };
      if (editing) {
        const { sku: _sku, ...rest } = payload;
        await api(`/api/inventory/${editing}`, { method: "PATCH", body: JSON.stringify(rest) });
        setOk("Product updated. Risk recalculated from stored demand and lead time.");
      } else {
        await api("/api/inventory", { method: "POST", body: JSON.stringify(payload) });
        setOk("Product created.");
      }
      setForm(emptyForm);
      setEditing(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Save failed");
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Inventory intelligence</h1>
        <p className="text-sm text-mute">
          Days of supply = on-hand / average daily demand. Stockout date = today + days of supply. Suggested reorder =
          demand during lead time + safety stock − (on-hand + pending POs).
        </p>
      </div>
      {error ? <ErrorBanner message={error} /> : null}
      {ok ? <SuccessBanner message={ok} /> : null}
      <div className="flex flex-wrap gap-2">
        <input className="input max-w-xs" placeholder="Search SKU or name" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input max-w-[160px]" value={risk} onChange={(e) => setRisk(e.target.value)} aria-label="Filter by risk">
          <option value="">All risk levels</option>
          {["critical", "high", "medium", "low", "unknown"].map((level) => (
            <option key={level} value={level}>
              {level}
            </option>
          ))}
        </select>
        <select className="input max-w-[160px]" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} aria-label="Sort">
          <option value="risk">Sort by risk</option>
          <option value="sku">Sort by SKU</option>
          <option value="stockout">Sort by stockout date</option>
        </select>
        <button className="btn-primary" type="button" onClick={load}>
          Apply
        </button>
      </div>
      {loading ? (
        <LoadingState />
      ) : sorted.length === 0 ? (
        <EmptyState title="No products" body="Create a SKU below or load demo data from the Action Center demo loader." />
      ) : (
        <div className="table-wrap">
          <table className="data">
            <thead>
              <tr>
                <th>SKU</th>
                <th>On hand</th>
                <th>Demand / day</th>
                <th>Lead time</th>
                <th>Stockout</th>
                <th>Reorder qty</th>
                <th>Risk</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((row) => (
                <tr key={row.id}>
                  <td>
                    <div className="font-medium">{row.sku}</div>
                    <div className="text-xs text-mute">
                      {row.name} · {inr(row.unit_cost)}
                      {row.sample_data ? " · sample" : ""}
                    </div>
                    <p className="mt-1 max-w-sm text-xs text-mute">{row.explanation}</p>
                  </td>
                  <td className="font-mono">
                    {row.quantity_on_hand}
                    <div className="text-xs text-mute">threshold {row.reorder_threshold}</div>
                  </td>
                  <td className="font-mono">{row.avg_daily_demand}</td>
                  <td className="font-mono">{row.lead_time_days}d</td>
                  <td className="font-mono">{row.expected_stockout_date || "—"}</td>
                  <td className="font-mono">{row.suggested_reorder_qty ?? "—"}</td>
                  <td>
                    <Badge level={row.risk_level}>{row.risk_level}</Badge>
                  </td>
                  <td>
                    <button
                      className="btn-ghost"
                      type="button"
                      onClick={() => {
                        setEditing(row.id);
                        setForm({
                          sku: row.sku,
                          name: row.name,
                          category: row.category,
                          quantity_on_hand: row.quantity_on_hand,
                          reorder_threshold: row.reorder_threshold,
                          safety_stock: row.safety_stock,
                          avg_daily_demand: row.avg_daily_demand,
                          unit_cost: row.unit_cost,
                          selling_price: row.selling_price,
                          lead_time_days: String(row.lead_time_days),
                        });
                      }}
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <form className="card grid gap-3 md:grid-cols-3" onSubmit={onSubmit}>
        <h2 className="md:col-span-3 font-medium">{editing ? `Edit ${form.sku}` : "Add product"}</h2>
        {Object.entries(form).map(([key, value]) => (
          <label key={key} className="text-sm">
            {key.replaceAll("_", " ")}
            <input
              className="input mt-1"
              value={value}
              onChange={(e) => setForm((prev) => ({ ...prev, [key]: e.target.value }))}
              required={key === "sku" || key === "name"}
              disabled={Boolean(editing) && key === "sku"}
            />
          </label>
        ))}
        <div className="md:col-span-3 flex gap-2">
          <button className="btn-primary" type="submit">
            {editing ? "Save changes" : "Create product"}
          </button>
          {editing ? (
            <button
              className="btn-ghost"
              type="button"
              onClick={() => {
                setEditing(null);
                setForm(emptyForm);
              }}
            >
              Cancel
            </button>
          ) : null}
        </div>
      </form>
    </div>
  );
}
