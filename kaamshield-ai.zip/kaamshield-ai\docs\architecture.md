# KaamShield AI — System Architecture
## NVIDIA × Nebius Global AI Hackathon (Best Apps & Agents Track)

### 1. High-Level Architecture Overview

KaamShield AI delivers operations intelligence and business stress testing for small-to-medium manufacturing enterprises (MSMEs). Rather than relying on ungrounded generative AI for math, KaamShield pairs **deterministic analytics engines** with **NVIDIA Nemotron 3** reasoning hosted on **Nebius Token Factory**.

```mermaid
flowchart TD
    subgraph UI ["Frontend (Next.js 14 + Tailwind CSS)"]
        DASH["Dashboard & KPI Deck"]
        SIM["Business Failure Simulator"]
        COPILOT["AI Operations Co-pilot"]
        AUDIT["Invoice & PO Auditor"]
        INV["Inventory Intelligence"]
        CASH["14 & 30-Day Cash Flow"]
        ACT["Executive Action Center"]
    end

    subgraph API ["FastAPI 0.110 Backend"]
        ROUTER["REST API Routers & CORS Middleware"]
        P_SCHEMA["Pydantic Schemas & Response Validators"]
    end

    subgraph ENGINES ["Deterministic Intelligence Engines"]
        E_INV["Inventory Stockout & Buffer Engine"]
        E_AUDIT["3-Way PO & Duplicate Invoice Auditor"]
        E_SUP["Supplier Reliability & Lead Time Engine"]
        E_CASH["Working Capital & Liquidity Forecaster"]
        E_SIM["Multi-Scenario Shock Engine"]
    end

    subgraph DATA ["Persistence Layer"]
        ORM["SQLAlchemy ORM Layer"]
        DB[("PostgreSQL / SQLite Storage")]
    end

    subgraph AI_CLOUD ["Nebius Token Factory & NVIDIA Cloud"]
        N_CLIENT["Nebius Token Factory Client"]
        NVIDIA["NVIDIA Nemotron 3 MoE (120B / Llama 70B)"]
        FALLBACK["Deterministic Rules Engine Fallback"]
    end

    UI -->|HTTP / JSON REST API| ROUTER
    ROUTER --> P_SCHEMA
    P_SCHEMA --> ENGINES
    ENGINES --> ORM
    ORM <--> DB

    COPILOT -->|1. Extract Live ERP Evidence| ENGINES
    ENGINES -->|2. Grounded Fact Matrix| N_CLIENT
    N_CLIENT -->|3. OpenAI-Compatible API| NVIDIA
    NVIDIA -->|4. Structured JSON Response| P_SCHEMA
    N_CLIENT -.->|Fallback on timeout/offline| FALLBACK
```

---

### 2. Core Subsystems

#### A. Deterministic Stockout Engine
- **Days of Supply**:
  $$\text{Days of Supply} = \frac{\text{Current Stock}}{\max(\text{Daily Demand}, 0.001)}$$
- **Replenishment Target**:
  $$\text{Target Inventory} = (\text{Daily Demand} \times (\text{Lead Time} + \text{Safety Buffer})) + \text{Safety Stock}$$
- **Suggested Order**:
  $$\text{Order Qty} = \max(0, \text{Target Inventory} - (\text{Current Stock} + \text{Pending PO Qty}))$$

#### B. Invoice & Duplicate Auditor
- Verifies line arithmetic: $\sum (\text{Qty} \times \text{Unit Price}) == \text{Invoice Total}$.
- Cross-references PO agreed contract rates and unfulfilled quantities.
- Multi-attribute duplicate detection: checks matching supplier ID, invoice number, and identical total amounts within a 30-day temporal window.

#### C. Flagship Business Failure Simulator
- Allows factory owners to simulate:
  - Supplier delays: $0$ to $14+$ days
  - Customer demand changes: $-50\%$ to $+100\%$
  - Material price hikes: $0\%$ to $50\%$
  - Receivables collection delays: $0$ to $45$ days
- Recalculates stockout windows, capacity revenue at risk, margin at risk, and projected liquidity shortfalls deterministically.
- Generates cheapest feasible mitigation options (e.g. split orders, air freight buffers, early collection discounts).

#### D. NVIDIA Nemotron via Nebius Token Factory
- Endpoint: `https://api.tokenfactory.nebius.com/v1/`
- Model: `nvidia/nemotron-3-super-120b-a12b` (or `nvidia/Llama-3.1-Nemotron-70B-Instruct-HF`)
- Low temperature ($0.2$) for factual precision.
- Grounded prompt includes live facts from DB (stockout days, variance amounts, delay days).
- Explicit fallback mechanism guarantees 100% application uptime even if credentials are not configured or cloud inference is temporarily unavailable.
