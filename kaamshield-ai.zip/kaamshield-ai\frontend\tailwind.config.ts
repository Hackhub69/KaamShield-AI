import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        brand: {
          bg: "#080B12",
          sidebar: "#0B1019",
          card: "#111827",
          surface: "#161F2E",
          surfaceHover: "#1C273A",
          border: "rgba(148, 163, 184, 0.12)",
          borderHover: "rgba(148, 163, 184, 0.25)",
          mint: "#8BFFB0",
          mintGlow: "rgba(139, 255, 176, 0.15)",
          critical: "#FF647C",
          criticalGlow: "rgba(255, 100, 124, 0.15)",
          warning: "#FFCA78",
          warningGlow: "rgba(255, 202, 120, 0.15)",
          info: "#76CFFF",
          infoGlow: "rgba(118, 207, 255, 0.15)",
          textPrimary: "#F4F7FB",
          textSecondary: "#97A3B6",
          textMuted: "#64748B",
        },
      },
      fontFamily: {
        sans: [
          "-apple-system",
          "BlinkMacSystemFont",
          '"Segoe UI"',
          "Roboto",
          '"Helvetica Neue"',
          "Inter",
          "sans-serif",
        ],
        mono: [
          '"JetBrains Mono"',
          '"Fira Code"',
          "Consolas",
          "Menlo",
          "monospace",
        ],
      },
      boxShadow: {
        "glow-mint": "0 0 20px -3px rgba(139, 255, 176, 0.25)",
        "glow-critical": "0 0 20px -3px rgba(255, 100, 124, 0.25)",
        "glow-card": "0 4px 20px -2px rgba(0, 0, 0, 0.5)",
      },
    },
  },
  plugins: [],
};
export default config;
