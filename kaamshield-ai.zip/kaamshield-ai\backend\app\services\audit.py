from sqlalchemy.orm import Session

from app.models.entities import AuditEvent


def record(
    db: Session,
    *,
    workspace_id: str,
    actor_id: str | None,
    action: str,
    entity_type: str,
    entity_id: str = "",
    details: str = "",
) -> None:
    db.add(
        AuditEvent(
            workspace_id=workspace_id,
            actor_id=actor_id,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            details=details[:2000],
        )
    )
