"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { api, clearToken, getToken } from "@/lib/api";
import type { AiStatus } from "@/lib/types";

const NAV = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/inventory", label: "Inventory" },
  { href: "/suppliers", label: "Suppliers" },
  { href: "/invoices", label: "Invoice auditor" },
  { href: "/cashflow", label: "Cash flow" },
  { href: "/simulator", label: "Failure simulator" },
  { href: "/copilot", label: "AI copilot" },
  { href: "/analysis", label: "AI analysis" },
  { href: "/actions", label: "Action center" },
];

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [me, setMe] = useState<{ name: string; workspace: string; is_demo: boolean; ai: AiStatus } | null>(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!getToken()) {
      router.replace("/");
      return;
    }
    api<{ name: string; workspace: string; is_demo: boolean; ai: AiStatus }>("/api/me")
      .then(setMe)
      .catch(() => router.replace("/"));
  }, [router]);

  const status = me?.ai.status ?? "configuration_required";
  const statusLabel =
    status === "connected" ? "Connected" : status === "configuration_required" ? "Configuration required" : "Temporarily unavailable";
  const statusColor =
    status === "connected" ? "bg-emerald-400" : status === "configuration_required" ? "bg-amber-400" : "bg-red-400";

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[240px_1fr]">
      <aside className={`border-b border-white/10 bg-navy-900 lg:border-b-0 lg:border-r ${open ? "block" : "hidden lg:block"}`}>
        <div className="flex items-center justify-between px-4 py-4">
          <div>
            <p className="text-sm font-semibold tracking-wide">KaamShield AI</p>
            <p className="text-xs text-mute">MSME operations copilot</p>
          </div>
          <button className="btn-ghost lg:hidden" type="button" onClick={() => setOpen(false)} aria-label="Close menu">
            Close
          </button>
        </div>
        <nav className="flex flex-col gap-1 px-2 pb-6" aria-label="Primary">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-md px-3 py-2 text-sm ${active ? "bg-white/10 text-ink" : "text-mute hover:bg-white/5 hover:text-ink"}`}
                onClick={() => setOpen(false)}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </aside>
      <div className="min-w-0">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-4 py-3">
          <button className="btn-ghost lg:hidden" type="button" onClick={() => setOpen(true)} aria-label="Open menu">
            Menu
          </button>
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">{me?.workspace || "Loading workspace"}</p>
            <p className="text-xs text-mute">
              {me?.is_demo ? "Synthetic demonstration workspace — not a live manufacturer." : me?.name}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 rounded-full border border-white/10 px-3 py-1 text-xs" title={me?.ai.role}>
              <span className={`h-2 w-2 rounded-full ${statusColor}`} aria-hidden />
              <span>Nemotron: {statusLabel}</span>
            </div>
            <button
              className="btn-ghost"
              type="button"
              onClick={() => {
                clearToken();
                router.replace("/");
              }}
            >
              Sign out
            </button>
          </div>
        </header>
        <main className="mx-auto max-w-7xl px-4 py-6">{children}</main>
      </div>
    </div>
  );
}
