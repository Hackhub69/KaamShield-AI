"use client";

import { riskClass } from "@/lib/api";

export function LoadingState({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="card text-sm text-mute" role="status">
      {label}
    </div>
  );
}

export function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="card border-dashed text-sm">
      <p className="font-medium text-ink">{title}</p>
      <p className="mt-1 text-mute">{body}</p>
    </div>
  );
}

export function ErrorBanner({ message }: { message: string }) {
  return (
    <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200" role="alert">
      {message}
    </div>
  );
}

export function SuccessBanner({ message }: { message: string }) {
  return (
    <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-200">
      {message}
    </div>
  );
}

export function Badge({ level, children }: { level?: string; children: React.ReactNode }) {
  return (
    <span className={`inline-flex rounded-full border px-2 py-0.5 text-xs capitalize ${riskClass(level || "")}`}>
      {children}
    </span>
  );
}

export function Metric({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <div className="card">
      <p className="text-xs uppercase tracking-wide text-mute">{label}</p>
      <p className="mt-2 font-mono text-2xl text-ink">{value}</p>
      {hint ? <p className="mt-1 text-xs text-mute">{hint}</p> : null}
    </div>
  );
}
