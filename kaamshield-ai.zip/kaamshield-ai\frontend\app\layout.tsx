import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "KaamShield AI",
  description: "Operations intelligence for MSMEs — inventory, invoices, cash, and NVIDIA Nemotron explanations.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans">{children}</body>
    </html>
  );
}
