import { NextResponse } from "next/server";
import { readFileSync } from "fs";
import { join } from "path";

export function GET() {
  const file = join(process.cwd(), "..", "sample_data", "invoices_template.csv");
  const body = readFileSync(file, "utf8");
  return new NextResponse(body, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": "attachment; filename=invoices_template.csv",
    },
  });
}
