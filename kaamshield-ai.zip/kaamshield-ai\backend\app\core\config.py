from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=(".env", "../.env"), extra="ignore")

    app_env: str = "development"
    secret_key: str = "dev-only-change-me"
    access_token_expire_minutes: int = 720
    database_url: str = "sqlite:///./kaamshield.db"
    cors_origins: str = "http://localhost:3000"
    demo_mode: bool = True
    demo_email: str = "demo@kaamshield.ai"
    demo_password: str = "demo-pass-2026"

    nebius_api_key: str = ""
    nebius_base_url: str = "https://api.tokenfactory.nebius.com/v1/"
    nvidia_nemotron_model: str = "nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B"
    ai_timeout_seconds: float = 45
    ai_max_retries: int = 1

    max_upload_bytes: int = Field(default=2 * 1024 * 1024)

    @property
    def cors_origin_list(self) -> list[str]:
        return [part.strip() for part in self.cors_origins.split(",") if part.strip()]

    @property
    def ai_configured(self) -> bool:
        return bool(self.nebius_api_key.strip())


@lru_cache
def get_settings() -> Settings:
    return Settings()
