from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Iterable


ZERO = Decimal("0")
QTY_TOLERANCE = Decimal("0.001")
PRICE_TOLERANCE = Decimal("0.01")


def _dec(value: Any) -> Decimal:
    if value is None or value == "":
        return ZERO
    return Decimal(str(value))


def normalize_document_id(value: str | None) -> str:
    if not value:
        return ""
    return "".join(ch.lower() for ch in value if ch.isalnum())


@dataclass
class Flag:
    code: str
    reason: str
    field: str
    original: str
    expected: str
    difference: str
    invoice_id: str | None = None
    related_invoice_id: str | None = None


@dataclass
class InvoiceAuditResult:
    invoice_id: str
    invoice_number: str
    flags: list[Flag] = field(default_factory=list)
    computed_total: Decimal = ZERO
    claimed_total: Decimal = ZERO

    @property
    def has_issues(self) -> bool:
        return bool(self.flags)


def line_total_should_equal(qty: Any, unit_price: Any, line_total: Any) -> Flag | None:
    expected = (_dec(qty) * _dec(unit_price)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    actual = _dec(line_total).quantize(Decimal("0.01"))
    if abs(expected - actual) > PRICE_TOLERANCE:
        return Flag(
            code="incorrect_line_total",
            reason="Line total does not equal quantity × unit price.",
            field="line_total",
            original=str(actual),
            expected=str(expected),
            difference=str((actual - expected).quantize(Decimal("0.01"))),
        )
    return None


def compare_invoice_to_po(
    *,
    invoice_id: str,
    invoice_number: str,
    invoice_supplier_id: str,
    po_supplier_id: str | None,
    claimed_total: Any,
    invoice_lines: Iterable[dict],
    po_lines: Iterable[dict] | None,
    receipt_qty_by_sku: dict[str, Any] | None = None,
) -> InvoiceAuditResult:
    flags: list[Flag] = []
    computed = ZERO
    lines = list(invoice_lines)
    for line in lines:
        computed += _dec(line.get("line_total"))
        mismatch = line_total_should_equal(line.get("quantity"), line.get("unit_price"), line.get("line_total"))
        if mismatch:
            mismatch.invoice_id = invoice_id
            flags.append(mismatch)

    claimed = _dec(claimed_total).quantize(Decimal("0.01"))
    computed = computed.quantize(Decimal("0.01"))
    if abs(claimed - computed) > PRICE_TOLERANCE:
        flags.append(
            Flag(
                code="incorrect_total",
                reason="Invoice claimed total does not match the sum of line totals.",
                field="claimed_total",
                original=str(claimed),
                expected=str(computed),
                difference=str((claimed - computed).quantize(Decimal("0.01"))),
                invoice_id=invoice_id,
            )
        )

    if po_supplier_id is None:
        flags.append(
            Flag(
                code="missing_purchase_order",
                reason="No matching purchase order was linked for this invoice.",
                field="purchase_order_id",
                original="",
                expected="linked PO",
                difference="",
                invoice_id=invoice_id,
            )
        )
    elif po_supplier_id != invoice_supplier_id:
        flags.append(
            Flag(
                code="unexpected_supplier_change",
                reason="Invoice supplier differs from the purchase order supplier.",
                field="supplier_id",
                original=invoice_supplier_id,
                expected=po_supplier_id,
                difference="",
                invoice_id=invoice_id,
            )
        )

    po_by_sku: dict[str, dict] = {}
    if po_lines:
        for po_line in po_lines:
            sku = str(po_line.get("sku") or "")
            po_by_sku[sku] = po_line

    if po_lines is not None:
        for line in lines:
            sku = str(line.get("sku") or "")
            po_line = po_by_sku.get(sku)
            if not po_line:
                flags.append(
                    Flag(
                        code="unmatched_sku",
                        reason=f"Invoice SKU {sku or '(blank)'} was not on the purchase order.",
                        field="sku",
                        original=sku,
                        expected="",
                        difference="",
                        invoice_id=invoice_id,
                    )
                )
                continue
            inv_qty = _dec(line.get("quantity"))
            po_qty = _dec(po_line.get("quantity"))
            if abs(inv_qty - po_qty) > QTY_TOLERANCE:
                flags.append(
                    Flag(
                        code="quantity_mismatch",
                        reason=f"Quantity for SKU {sku} differs from the purchase order.",
                        field="quantity",
                        original=str(inv_qty),
                        expected=str(po_qty),
                        difference=str(inv_qty - po_qty),
                        invoice_id=invoice_id,
                    )
                )
            inv_price = _dec(line.get("unit_price"))
            po_price = _dec(po_line.get("unit_price"))
            if abs(inv_price - po_price) > PRICE_TOLERANCE:
                flags.append(
                    Flag(
                        code="unit_price_mismatch",
                        reason=f"Unit price for SKU {sku} differs from the purchase order.",
                        field="unit_price",
                        original=str(inv_price),
                        expected=str(po_price),
                        difference=str((inv_price - po_price).quantize(Decimal("0.01"))),
                        invoice_id=invoice_id,
                    )
                )

    if receipt_qty_by_sku:
        for line in lines:
            sku = str(line.get("sku") or "")
            if sku not in receipt_qty_by_sku:
                continue
            inv_qty = _dec(line.get("quantity"))
            rec_qty = _dec(receipt_qty_by_sku.get(sku))
            if abs(inv_qty - rec_qty) > QTY_TOLERANCE:
                flags.append(
                    Flag(
                        code="goods_receipt_quantity_mismatch",
                        reason=f"Invoice quantity for SKU {sku} differs from goods-received quantity.",
                        field="quantity",
                        original=str(inv_qty),
                        expected=str(rec_qty),
                        difference=str(inv_qty - rec_qty),
                        invoice_id=invoice_id,
                    )
                )

    return InvoiceAuditResult(
        invoice_id=invoice_id,
        invoice_number=invoice_number,
        flags=flags,
        computed_total=computed,
        claimed_total=claimed,
    )


def find_duplicate_candidates(invoices: Iterable[dict]) -> list[Flag]:
    """Flag possible duplicates for review. Never auto-declares fraud."""
    flags: list[Flag] = []
    rows = list(invoices)
    by_number: dict[tuple[str, str], list[dict]] = {}
    for inv in rows:
        key = (str(inv.get("supplier_id")), str(inv.get("invoice_number")).strip().lower())
        by_number.setdefault(key, []).append(inv)

    for (_supplier, number), group in by_number.items():
        if number and len(group) > 1:
            first, *rest = group
            for other in rest:
                flags.append(
                    Flag(
                        code="repeated_invoice_number",
                        reason="The same invoice number appears more than once for this supplier. Review before paying.",
                        field="invoice_number",
                        original=str(other.get("invoice_number")),
                        expected="unique number per supplier",
                        difference="",
                        invoice_id=str(other.get("id")),
                        related_invoice_id=str(first.get("id")),
                    )
                )

    for i, a in enumerate(rows):
        for b in rows[i + 1 :]:
            if a.get("id") == b.get("id"):
                continue
            if a.get("supplier_id") != b.get("supplier_id"):
                continue
            same_amount = _dec(a.get("claimed_total")) == _dec(b.get("claimed_total")) and _dec(a.get("claimed_total")) > 0
            date_a: date | None = a.get("invoice_date")
            date_b: date | None = b.get("invoice_date")
            close_dates = False
            if date_a and date_b:
                close_dates = abs((date_a - date_b).days) <= 3
            same_doc = normalize_document_id(a.get("document_id")) and (
                normalize_document_id(a.get("document_id")) == normalize_document_id(b.get("document_id"))
            )
            number_same = str(a.get("invoice_number")).strip().lower() == str(b.get("invoice_number")).strip().lower()
            if number_same:
                continue
            score = sum([same_amount, close_dates, same_doc])
            if score >= 2:
                flags.append(
                    Flag(
                        code="possible_duplicate_invoice",
                        reason=(
                            "Possible duplicate: overlapping supplier, amount, date proximity, "
                            "and/or normalized document identifier. Flagged for review, not confirmed fraud."
                        ),
                        field="invoice",
                        original=str(b.get("invoice_number")),
                        expected=str(a.get("invoice_number")),
                        difference="",
                        invoice_id=str(b.get("id")),
                        related_invoice_id=str(a.get("id")),
                    )
                )
    return flags


def sanitize_csv_cell(value: str) -> str:
    """Neutralize spreadsheet formula injection on export."""
    if not value:
        return value
    if value[0] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + value
    return value
