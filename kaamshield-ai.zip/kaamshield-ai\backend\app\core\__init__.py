"""Core configuration and infrastructure."""
