"use client";

import { useEffect, useState } from "react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api, inr } from "@/lib/api";
import { EmptyState, ErrorBanner, LoadingState, Metric } from "@/components/ui";

type CashPayload = {
  opening_cash: string;
  horizon_days: number;
  min_balance: string;
  min_balance_date: string | null;
  shortfall_dates: string[];
  assumptions: string[];
  daily: { day: string; inflow: string; outflow: string; balance: string; notes: string[] }[];
  overdue_receivables: { id: string; customer_name: string; invoice_number: string; amount: string; due_on: string; assumption: string }[];
};

export default function CashflowPage() {
  const [horizon, setHorizon] = useState(14);
  const [data, setData] = useState<CashPayload | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api<CashPayload>(`/api/cashflow?horizon=${horizon}`)
      .then(setData)
      .catch((err) => setError(err.message));
  }, [horizon]);

  if (error) return <ErrorBanner message={error} />;
  if (!data) return <LoadingState label="Projecting cash from receivables, payables, and opex…" />;
  if (data.daily.length === 0) {
    return <EmptyState title="No cash-flow inputs" body="Add receivables, invoices, or cash entries to project balances." />;
  }

  const chart = data.daily.map((d) => ({ day: d.day.slice(5), balance: Number(d.balance) }));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Cash-flow forecast</h1>
          <p className="text-sm text-mute">Receipts are not assumed on time if they are overdue without a future expected date.</p>
        </div>
        <label className="text-sm">
          Horizon
          <select className="input mt-1" value={horizon} onChange={(e) => setHorizon(Number(e.target.value))}>
            <option value={14}>14 days</option>
            <option value={30}>30 days</option>
          </select>
        </label>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <Metric label="Opening cash" value={inr(data.opening_cash)} />
        <Metric label="Lowest projected balance" value={inr(data.min_balance)} hint={data.min_balance_date || undefined} />
        <Metric
          label="Shortfall dates"
          value={data.shortfall_dates.length ? String(data.shortfall_dates.length) : "None"}
          hint={data.shortfall_dates.join(", ") || "Balance stays non-negative under stated assumptions"}
        />
      </div>
      <div className="card h-72">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chart}>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" />
            <XAxis dataKey="day" stroke="#94A3B8" />
            <YAxis stroke="#94A3B8" />
            <Tooltip />
            <Line type="monotone" dataKey="balance" stroke="#38BDF8" dot={false} name="Projected cash" />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <section className="card">
        <h2 className="font-medium">Overdue receivables</h2>
        {data.overdue_receivables.length === 0 ? (
          <p className="mt-2 text-sm text-mute">None overdue.</p>
        ) : (
          <ul className="mt-3 space-y-2 text-sm">
            {data.overdue_receivables.map((row) => (
              <li key={row.id}>
                {row.customer_name} · {row.invoice_number} · {inr(row.amount)} due {row.due_on}
                <span className="block text-xs text-mute">{row.assumption}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
      <section className="card">
        <h2 className="font-medium">Assumptions</h2>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-mute">
          {data.assumptions.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>
    </div>
  );
}
