from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import hash_password
from app.models.entities import (
    CashFlowEntry,
    GoodsReceipt,
    GoodsReceiptLine,
    InventoryMovement,
    Invoice,
    InvoiceLine,
    Product,
    PurchaseOrder,
    PurchaseOrderLine,
    Receivable,
    Supplier,
    User,
    Workspace,
)
from app.services.actions import rebuild_actions

DEMO_SLUG = "prakash-precision-demo"


def ensure_demo_workspace(db: Session, *, reset: bool = False) -> Workspace:
    settings = get_settings()
    workspace = db.scalar(select(Workspace).where(Workspace.slug == DEMO_SLUG))
    if workspace and not reset:
        user = db.scalar(select(User).where(User.email == settings.demo_email))
        if not user:
            _demo_user(db, workspace)
            db.flush()
        return workspace
    if workspace and reset:
        _wipe_workspace(db, workspace.id)
        db.delete(workspace)
        db.flush()
    workspace = _build(db)
    rebuild_actions(db, workspace)
    db.flush()
    return workspace


def _wipe_workspace(db: Session, workspace_id: str) -> None:
    from app.models.entities import (
        ActionEvent,
        AiAnalysisRecord,
        AuditEvent,
        RecommendedAction,
        RiskAssessment,
        SimulationScenario,
    )

    for model in (
        ActionEvent,
        RecommendedAction,
        AiAnalysisRecord,
        AuditEvent,
        RiskAssessment,
        SimulationScenario,
        InventoryMovement,
        InvoiceLine,
        Invoice,
        GoodsReceiptLine,
        GoodsReceipt,
        PurchaseOrderLine,
        PurchaseOrder,
        Receivable,
        CashFlowEntry,
        Product,
        Supplier,
        User,
    ):
        if model is ActionEvent:
            actions = db.scalars(select(RecommendedAction).where(RecommendedAction.workspace_id == workspace_id)).all()
            for action in actions:
                for event in list(action.events):
                    db.delete(event)
            continue
        if model is InvoiceLine:
            invoices = db.scalars(select(Invoice).where(Invoice.workspace_id == workspace_id)).all()
            for inv in invoices:
                for line in list(inv.lines):
                    db.delete(line)
            continue
        if model is GoodsReceiptLine:
            receipts = db.scalars(select(GoodsReceipt).where(GoodsReceipt.workspace_id == workspace_id)).all()
            for rec in receipts:
                for line in list(rec.lines):
                    db.delete(line)
            continue
        if model is PurchaseOrderLine:
            pos = db.scalars(select(PurchaseOrder).where(PurchaseOrder.workspace_id == workspace_id)).all()
            for po in pos:
                for line in list(po.lines):
                    db.delete(line)
            continue
        rows = db.scalars(select(model).where(model.workspace_id == workspace_id)).all()
        for row in rows:
            db.delete(row)
    db.flush()


def _demo_user(db: Session, workspace: Workspace) -> User:
    settings = get_settings()
    user = User(
        workspace_id=workspace.id,
        email=settings.demo_email,
        full_name="Anjali Deshmukh",
        hashed_password=hash_password(settings.demo_password),
        role="owner",
    )
    db.add(user)
    return user


def _build(db: Session) -> Workspace:
    today = date.today()
    workspace = Workspace(
        slug=DEMO_SLUG,
        name="Prakash Precision Components Pvt Ltd",
        city="Pimpri-Chinchwad, Pune",
        currency="INR",
        is_demo=True,
        opening_cash=Decimal("485000.00"),
    )
    db.add(workspace)
    db.flush()
    _demo_user(db, workspace)

    suppliers_spec = [
        ("SUP-AAR", "Aarav Fasteners, Bhosari", "Pune", "Fasteners", 7),
        ("SUP-NASH", "Nashik Heat Treat Co.", "Nashik", "Heat treatment", 10),
        ("SUP-CHN", "Chennai Coil Stampings", "Chennai", "Stampings", 14),
        ("SUP-RAJK", "Rajkot Bearing House", "Rajkot", "Bearings", 12),
        ("SUP-DEL", "Delhi Polymer Seals", "Delhi NCR", "Seals", 8),
        ("SUP-KOL", "Howrah Casting Works", "Howrah", "Castings", 18),
    ]
    suppliers: dict[str, Supplier] = {}
    for key, name, city, category, lead in suppliers_spec:
        row = Supplier(
            workspace_id=workspace.id,
            name=name,
            city=city,
            category=category,
            stated_lead_time_days=lead,
            notes="Synthetic sample supplier for the demonstration workspace.",
            sample_data=True,
        )
        db.add(row)
        db.flush()
        suppliers[key] = row

    catalog = [
        ("SKU-M8-HEX", "M8 Hex Bolt 8.8 grade", "Fasteners", "SUP-AAR", 420, 250, 80, 18.5, 9.4, 24.0, 7),
        ("SKU-M8-NUT", "M8 Nylon Lock Nut", "Fasteners", "SUP-AAR", 900, 400, 120, 22.0, 3.1, 7.5, 7),
        ("SKU-M10-HEX", "M10 Hex Bolt 8.8 grade", "Fasteners", "SUP-AAR", 110, 180, 60, 14.0, 14.8, 32.0, 7),
        ("SKU-WASHER", "M8 Spring Washer", "Fasteners", "SUP-AAR", 1400, 500, 150, 30.0, 0.9, 2.4, 7),
        ("SKU-M12-SHCS", "M12 Socket Head Cap Screw", "Fasteners", "SUP-AAR", 75, 90, 30, 6.5, 28.0, 55.0, 7),
        ("SKU-HT-M8", "Heat-treated M8 blank", "Process", "SUP-NASH", 60, 80, 25, 8.0, 6.2, 0, 10),
        ("SKU-HT-SHAFT", "Heat-treated 20mm shaft", "Process", "SUP-NASH", 22, 40, 12, 3.2, 185.0, 0, 10),
        ("SKU-LAM-50", "50mm Stamping lamination", "Stampings", "SUP-CHN", 180, 200, 40, 22.0, 11.5, 19.0, 14),
        ("SKU-LAM-80", "80mm Stamping lamination", "Stampings", "SUP-CHN", 40, 90, 20, 9.5, 18.0, 29.0, 14),
        ("SKU-BRG-6204", "6204 ZZ Bearing", "Bearings", "SUP-RAJK", 48, 60, 15, 5.0, 92.0, 145.0, 12),
        ("SKU-BRG-6205", "6205 ZZ Bearing", "Bearings", "SUP-RAJK", 16, 40, 12, 4.2, 118.0, 180.0, 12),
        ("SKU-BRG-6304", "6304 Open Bearing", "Bearings", "SUP-RAJK", 70, 35, 10, 3.0, 140.0, 210.0, 12),
        ("SKU-SEAL-25", "Nitrile oil seal 25x40x7", "Seals", "SUP-DEL", 210, 120, 40, 12.0, 18.5, 32.0, 8),
        ("SKU-SEAL-35", "Nitrile oil seal 35x52x8", "Seals", "SUP-DEL", 55, 80, 25, 7.5, 22.0, 38.0, 8),
        ("SKU-ORING-110", "Viton O-ring 110mm", "Seals", "SUP-DEL", 30, 50, 15, 4.0, 14.0, 26.0, 8),
        ("SKU-HSG-A", "Housing casting A", "Castings", "SUP-KOL", 18, 20, 6, 1.8, 420.0, 690.0, 18),
        ("SKU-HSG-B", "Housing casting B", "Castings", "SUP-KOL", 9, 16, 5, 1.4, 510.0, 820.0, 18),
        ("SKU-COVER", "End cover casting", "Castings", "SUP-KOL", 28, 24, 8, 2.1, 260.0, 410.0, 18),
        ("SKU-PIN-6", "Dowel pin 6x20", "Fasteners", "SUP-AAR", 500, 200, 60, 16.0, 2.4, 5.5, 7),
        ("SKU-PIN-8", "Dowel pin 8x25", "Fasteners", "SUP-AAR", 40, 120, 40, 9.0, 3.6, 7.2, 7),
        ("SKU-SPACER", "Aluminium spacer 12mm", "Stampings", "SUP-CHN", 95, 70, 20, 6.0, 16.5, 28.0, 14),
        ("SKU-GREASE", "EP2 grease 1kg", "Consumable", "SUP-RAJK", 12, 8, 3, 0.6, 240.0, 0, 12),
        ("SKU-GASKET", "Paper gasket sheet A4", "Seals", "SUP-DEL", 80, 40, 10, 3.5, 35.0, 55.0, 8),
        ("SKU-CABLE", "3-core cable 1.5sqmm (m)", "Electrical", "SUP-CHN", 250, 100, 30, 12.0, 22.0, 0, 14),
        ("SKU-TERM", "Ring terminal M5 pack", "Electrical", "SUP-DEL", 600, 200, 50, 20.0, 4.8, 9.5, 8),
        ("SKU-FAN-92", "92mm cooling fan", "Electrical", "SUP-CHN", 14, 20, 6, 1.6, 310.0, 480.0, 14),
    ]
    products: dict[str, Product] = {}
    for sku, name, category, sup, qty, reorder, safety, demand, cost, price, lead in catalog:
        row = Product(
            workspace_id=workspace.id,
            supplier_id=suppliers[sup].id,
            sku=sku,
            name=name,
            category=category,
            quantity_on_hand=Decimal(qty),
            reorder_threshold=Decimal(reorder),
            safety_stock=Decimal(safety),
            avg_daily_demand=Decimal(str(demand)),
            unit_cost=Decimal(str(cost)),
            selling_price=Decimal(str(price)),
            lead_time_days=lead,
            sample_data=True,
        )
        db.add(row)
        db.flush()
        products[sku] = row
        db.add(
            InventoryMovement(
                workspace_id=workspace.id,
                product_id=row.id,
                occurred_on=today - timedelta(days=12),
                quantity_delta=Decimal(qty),
                reason="opening_balance",
                reference="DEMO-OPEN",
            )
        )

    def add_po(number, supplier_key, ordered_off, promised_off, status, lines, received_off=None):
        po = PurchaseOrder(
            workspace_id=workspace.id,
            supplier_id=suppliers[supplier_key].id,
            po_number=number,
            status=status,
            ordered_on=today - timedelta(days=ordered_off),
            promised_on=today - timedelta(days=promised_off) if promised_off >= 0 else today + timedelta(days=-promised_off),
            received_on=(today - timedelta(days=received_off)) if received_off is not None else None,
            notes="Synthetic sample purchase order.",
            sample_data=True,
        )
        if promised_off < 0:
            po.promised_on = today + timedelta(days=-promised_off)
        db.add(po)
        db.flush()
        for sku, qty, price in lines:
            db.add(
                PurchaseOrderLine(
                    purchase_order_id=po.id,
                    product_id=products[sku].id,
                    quantity=Decimal(qty),
                    unit_price=Decimal(str(price)),
                )
            )
        return po

    po_ok = add_po("PO-24018", "SUP-AAR", 20, 12, "received", [("SKU-M8-HEX", 400, 9.4), ("SKU-WASHER", 800, 0.9)], received_off=11)
    po_ht = add_po("PO-24021", "SUP-NASH", 18, 8, "received", [("SKU-HT-SHAFT", 20, 185.0)], received_off=9)
    po_delay_bearings = add_po(
        "PO-24030",
        "SUP-RAJK",
        16,
        3,
        "delayed",
        [("SKU-BRG-6205", 40, 118.0), ("SKU-BRG-6204", 30, 92.0)],
    )
    po_delay_castings = add_po(
        "PO-24031",
        "SUP-KOL",
        22,
        4,
        "delayed",
        [("SKU-HSG-A", 12, 420.0), ("SKU-HSG-B", 8, 510.0)],
    )
    po_open_seals = add_po(
        "PO-24040",
        "SUP-DEL",
        4,
        -6,
        "open",
        [("SKU-SEAL-35", 80, 22.0), ("SKU-ORING-110", 40, 14.0)],
    )
    po_open_stamp = add_po(
        "PO-24041",
        "SUP-CHN",
        3,
        -10,
        "open",
        [("SKU-LAM-80", 80, 18.0), ("SKU-FAN-92", 10, 310.0)],
    )

    rec = GoodsReceipt(workspace_id=workspace.id, purchase_order_id=po_ok.id, received_on=today - timedelta(days=11), notes="On time")
    db.add(rec)
    db.flush()
    db.add(GoodsReceiptLine(goods_receipt_id=rec.id, product_id=products["SKU-M8-HEX"].id, quantity=Decimal("400")))
    rec2 = GoodsReceipt(workspace_id=workspace.id, purchase_order_id=po_ht.id, received_on=today - timedelta(days=9), notes="One day late")
    db.add(rec2)
    db.flush()
    db.add(GoodsReceiptLine(goods_receipt_id=rec2.id, product_id=products["SKU-HT-SHAFT"].id, quantity=Decimal("20")))

    def add_invoice(number, supplier_key, po, inv_off, due_off, status, lines, claimed=None, document=""):
        inv = Invoice(
            workspace_id=workspace.id,
            supplier_id=suppliers[supplier_key].id,
            purchase_order_id=po.id if po else None,
            invoice_number=number,
            invoice_date=today - timedelta(days=inv_off),
            due_date=today + timedelta(days=due_off),
            status=status,
            document_id=document,
            sample_data=True,
        )
        db.add(inv)
        db.flush()
        total = Decimal("0")
        for sku, qty, price, line_total in lines:
            db.add(
                InvoiceLine(
                    invoice_id=inv.id,
                    product_id=products[sku].id,
                    sku=sku,
                    description=products[sku].name,
                    quantity=Decimal(qty),
                    unit_price=Decimal(str(price)),
                    line_total=Decimal(str(line_total)),
                )
            )
            total += Decimal(str(line_total))
        inv.claimed_total = Decimal(str(claimed)) if claimed is not None else total
        return inv

    add_invoice(
        "INV-AAR-881",
        "SUP-AAR",
        po_ok,
        10,
        5,
        "unpaid",
        [("SKU-M8-HEX", 400, 9.4, 3760), ("SKU-WASHER", 800, 0.9, 720)],
        document="aar-881",
    )
    add_invoice(
        "INV-RAJ-220",
        "SUP-RAJK",
        po_delay_bearings,
        2,
        8,
        "unpaid",
        [("SKU-BRG-6205", 50, 130.0, 6500), ("SKU-BRG-6204", 30, 92.0, 2760)],
        claimed=9500,
        document="raj-220",
    )
    add_invoice(
        "INV-RAJ-220",
        "SUP-RAJK",
        po_delay_bearings,
        1,
        8,
        "unpaid",
        [("SKU-BRG-6205", 50, 130.0, 6500), ("SKU-BRG-6204", 30, 92.0, 2760)],
        claimed=9260,
        document="raj220",
    )
    add_invoice(
        "INV-KOL-044",
        "SUP-KOL",
        po_delay_castings,
        3,
        12,
        "unpaid",
        [("SKU-HSG-A", 12, 420.0, 5040), ("SKU-HSG-B", 8, 510.0, 4080)],
        document="kol-044",
    )
    add_invoice(
        "INV-DEL-910",
        "SUP-DEL",
        po_open_seals,
        1,
        10,
        "unpaid",
        [("SKU-SEAL-35", 80, 22.0, 1760), ("SKU-ORING-110", 40, 14.0, 560)],
        document="del-910",
    )
    add_invoice(
        "INV-ORPHAN-1",
        "SUP-CHN",
        None,
        2,
        6,
        "unpaid",
        [("SKU-LAM-80", 20, 22.0, 440)],
        claimed=440,
        document="orphan-1",
    )

    customers = [
        ("Tata AutoComp vendor pack", "AR-4401", 185000, 18, 4, None, "open"),
        ("Bajaj tier-2 job work", "AR-4408", 92000, 12, -3, today + timedelta(days=9), "open"),
        ("Local OEM spare kit", "AR-4412", 41000, 6, 8, None, "open"),
        ("Export packing (overdue, no new date)", "AR-4388", 76000, 25, -10, None, "open"),
    ]
    for name, number, amount, issued_off, due_off, expected, status in customers:
        db.add(
            Receivable(
                workspace_id=workspace.id,
                customer_name=name,
                invoice_number=number,
                amount=Decimal(amount),
                issued_on=today - timedelta(days=issued_off),
                due_on=today + timedelta(days=due_off),
                expected_on=expected,
                status=status,
                payment_assumption=(
                    "Overdue: not assumed to arrive unless expected_on is set."
                    if due_off < 0 and expected is None
                    else "Scheduled on due date unless expected_on is provided."
                ),
                sample_data=True,
            )
        )

    for offset, amount, desc in [(2, 38000, "Wages weekly"), (9, 38000, "Wages weekly"), (5, 14000, "MSEB electricity"), (11, 9000, "GST outgo provision")]:
        db.add(
            CashFlowEntry(
                workspace_id=workspace.id,
                entry_date=today + timedelta(days=offset),
                amount=Decimal(amount),
                direction="out",
                category="opex",
                description=desc,
                source_type="opex",
                sample_data=True,
            )
        )
    return workspace
