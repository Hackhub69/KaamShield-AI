"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { EmptyState, ErrorBanner, LoadingState, Badge } from "@/components/ui";
import type { AiStatus } from "@/lib/types";

type Analysis = {
  id: string;
  query: string;
  model_id: string;
  provider_status: string;
  fallback_used: boolean;
  latency_ms: number | null;
  created_at: string | null;
  response: { summary?: string; recommended_actions?: { title: string }[] };
  evidence: { inventory_risks?: unknown[]; invoice_flags?: unknown[]; cash_14d?: unknown };
};

export default function AnalysisPage() {
  const [status, setStatus] = useState<AiStatus | null>(null);
  const [rows, setRows] = useState<Analysis[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api<AiStatus>("/api/ai/status"), api<Analysis[]>("/api/ai/analyses")])
      .then(([s, a]) => {
        setStatus(s);
        setRows(a);
      })
      .catch((err) => setError(err.message));
  }, []);

  if (error) return <ErrorBanner message={error} />;
  if (!status) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">AI analysis pipeline</h1>
        <p className="text-sm text-mute">{status.attribution}. {status.role}</p>
      </div>
      <ol className="grid gap-3 md:grid-cols-5">
        {[
          "1. Business data stored",
          "2. Deterministic calculations",
          "3. Evidence package to Nemotron",
          "4. Structured explanation",
          "5. Recommendation recorded",
        ].map((step) => (
          <li key={step} className="card text-sm">
            {step}
          </li>
        ))}
      </ol>
      <section className="card space-y-2">
        <h2 className="font-medium">Configured model</h2>
        <p className="font-mono text-sm">{status.model}</p>
        <p className="text-sm text-mute">Host: {status.base_url_host || "not set"}</p>
        <Badge level={status.status === "connected" ? "low" : "high"}>{status.status.replaceAll("_", " ")}</Badge>
        {status.status === "configuration_required" ? (
          <p className="text-sm text-mute">
            Set NEBIUS_API_KEY in the backend environment. Create a key in Nebius Token Factory, keep it off the frontend, and restart the API.
            Documented base URL: https://api.tokenfactory.nebius.com/v1/
          </p>
        ) : null}
      </section>
      {rows.length === 0 ? (
        <EmptyState title="No analysis records yet" body="Ask a question in the copilot to store evidence, latency, and the model response." />
      ) : (
        <div className="space-y-3">
          {rows.map((row) => (
            <article key={row.id} className="card space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="text-sm font-medium">{row.query}</h2>
                <Badge level={row.fallback_used ? "high" : "low"}>{row.fallback_used ? "fallback" : row.model_id}</Badge>
              </div>
              <p className="text-sm">{row.response.summary}</p>
              <p className="text-xs text-mute">
                Evidence included {Array.isArray(row.evidence.inventory_risks) ? row.evidence.inventory_risks.length : 0} inventory risks and{" "}
                {Array.isArray(row.evidence.invoice_flags) ? row.evidence.invoice_flags.length : 0} invoice flags. Latency {row.latency_ms ?? "n/a"} ms.
              </p>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
