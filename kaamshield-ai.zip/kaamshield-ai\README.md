# KaamShield AI 🛡️
### Production Operations Intelligence & Business Failure Simulator for MSMEs
**NVIDIA × Nebius Global AI Hackathon — Best Apps & Agents Track**

<p align="center">
  <img src="https://img.shields.io/badge/Status-Production%20Ready-00F5A0?style=for-the-badge&logo=statuspage&logoColor=white" alt="Status" />
  <img src="https://img.shields.io/badge/Model-NVIDIA%20Nemotron%203%20MoE-76B900?style=for-the-badge&logo=nvidia&logoColor=white" alt="NVIDIA Nemotron" />
  <img src="https://img.shields.io/badge/Inference-Nebius%20Token%20Factory-00D26A?style=for-the-badge&logo=lightning&logoColor=white" alt="Nebius Token Factory" />
  <img src="https://img.shields.io/badge/Frontend-Next.js%2014%20%7C%20Tailwind-black?style=for-the-badge&logo=nextdotjs&logoColor=white" alt="Next.js" />
  <img src="https://img.shields.io/badge/Backend-FastAPI%20%7C%20Python%203.11+-009688?style=for-the-badge&logo=fastapi&logoColor=white" alt="FastAPI" />
  <img src="https://img.shields.io/badge/Tests-6%2F6%20Passing%20(100%25)-brightgreen?style=for-the-badge&logo=pytest&logoColor=white" alt="Pytest" />
  <img src="https://img.shields.io/badge/License-MIT-blue?style=for-the-badge" alt="License" />
</p>

> *"See the risk. Prevent the loss."*  
> **KaamShield AI** is an AI operations command center engineered for manufacturing MSMEs. It bridges real-time factory ledgers with **NVIDIA Nemotron 3 MoE** reasoning served through **Nebius Token Factory**, pairing verifiable deterministic business logic with zero-hallucination operational advisory.

---

## 📌 Table of Contents
1. [The Real-World Problem](#-the-real-world-problem)
2. [Key Product Innovations](#-key-product-innovations)
3. [NVIDIA Nemotron × Nebius Token Factory Integration](#-nvidia-nemotron--nebius-token-factory-integration)
4. [System Architecture](#-system-architecture)
5. [Core Mathematical & Deterministic Formulas](#-core-mathematical--deterministic-formulas)
6. [Interactive Application Workspaces](#-interactive-application-workspaces)
7. [Quickstart & Local Installation](#-quickstart--local-installation)
8. [Automated Verification & Test Suite](#-automated-verification--test-suite)
9. [Docker Deployment](#-docker-deployment)
10. [Hackathon Evaluation Checklist](#-hackathon-evaluation-checklist)
11. [License](#-license)

---

## 🏭 The Real-World Problem

Over 63 million Micro, Small, and Medium Enterprises (MSMEs) power global industrial manufacturing. In sectors like automotive tooling, precision engineering, and electronics assembly, businesses operate on thin margins ($8\text{--}14\%$) with fragmented ERPs and paper invoices. 

**82% of small manufacturer insolvencies stem from operational shocks discovered too late:**
- **Lead-Time Blindness:** Critical raw alloy bars or fasteners run out mid-production due to unannounced vendor delays.
- **Invoice Discrepancies & Price Creep:** Suppliers invoice at inflated unit rates (e.g. ₹315/pc vs. agreed ₹285/pc) or bill for quantities exceeding approved Purchase Orders.
- **Duplicate Invoices:** Identical vendor invoices submitted weeks apart bypass manual spreadsheet checks.
- **Cash-Flow Cliff:** Client payment delays collide with scheduled bi-weekly payroll and power bills, triggering immediate liquidity failure.

Existing ERPs act as passive historical recorders. **KaamShield AI acts as an active, preventative co-pilot.**

---

## ⚡ Key Product Innovations

### 1. Flagship: Business Failure Simulator
A split-screen stress-testing studio allowing plant owners and financial controllers to simulate shocks before committing working capital:
- **Supplier Delay (0–14 Days):** Recalculates exact stock runout dates and unfulfilled capacity revenue at risk.
- **Demand Surges / Drops (-50% to +100%):** Models safety stock depletion and automated reorder buffers.
- **Customer Payment Delays (0–45 Days):** Pinpoints the exact calendar date of working capital insolvency.
- **Raw Material Price Hikes (0–50%):** Quantifies direct gross margin erosion.
- **Cheapest Feasible Mitigations:** Delivers instant, mathematically derived contingency plans (e.g., air-freighting partial batches vs. offering 2% early-collection discounts).

### 2. Dual-Engine Intelligence: Factual Grounding + Nemotron Reasoning
- **Never hallucinates financial figures:** All quantities, variances, and dates are derived deterministically in Python/NumPy/Pandas.
- **Contextual synthesis via NVIDIA Nemotron 3:** Operates strictly on a structured **Operational Evidence Package** extracted from database records.
- **100% Uptime Fallback:** If cloud inference is offline or unconfigured, the system automatically falls back to KaamShield's **Deterministic Intelligence Engine** with clear UI labeling.

---

## 🧠 NVIDIA Nemotron × Nebius Token Factory Integration

KaamShield AI integrates **NVIDIA Nemotron 3 MoE** hosted on **Nebius Token Factory** using its OpenAI-compatible endpoint.

```
┌────────────────────────────────────────────────────────┐
│               ERP / Database Ledger Records            │
│  (Stock levels, Overdue POs, Audited Invoices, Cash)   │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│           Operational Evidence Matrix Builder          │
│   (Grounded JSON extraction with zero invented stats)  │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│             Nebius Token Factory API Client            │
│       Base URL: https://api.tokenfactory.nebius.com/v1/│
│       Model: nvidia/nemotron-3-super-120b-a12b         │
│       Temperature: 0.2 (High-precision deterministic)  │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│              Structured Pydantic Validation            │
│   - Executive Summary       - Identified Risks         │
│   - Supporting Citations    - Recommended Actions      │
│   - Quantified Impact       - Analytical Confidence    │
└────────────────────────────────────────────────────────┘
```

### Configuration Environment
In `.env`:
```bash
NEBIUS_API_KEY=your_nebius_token_factory_key
NEBIUS_BASE_URL=https://api.tokenfactory.nebius.com/v1/
NVIDIA_NEMOTRON_MODEL=nvidia/nemotron-3-super-120b-a12b
```
*(If `NEBIUS_API_KEY` is not provided, KaamShield seamlessly runs in Deterministic Engine mode with 100% feature availability).*

---

## 🏛️ System Architecture

```
kaamshield-ai/
├── backend/
│   ├── app/
│   │   ├── ai/            # Nebius Token Factory client & ERP evidence extractor
│   │   ├── analytics/     # Stockout, 3-way invoice audit, supplier risk, cash flow, simulator
│   │   ├── api/           # REST endpoints (health, dashboard, inventory, simulator, copilot, demo)
│   │   ├── core/          # Pydantic Settings, database engine, SQLite/PostgreSQL configuration
│   │   ├── models/        # Normalized SQLAlchemy tables
│   │   ├── schemas/       # Typed Pydantic request/response schemas
│   │   ├── tests/         # Pytest automated test suite (6/6 passing)
│   │   └── main.py        # FastAPI app entrypoint
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   ├── app/               # Next.js 14 App Router (layout, page, theme)
│   ├── components/        # Dashboard, Simulator, Copilot, Inventory, Auditor, CashFlow, ActionCenter
│   ├── components/ui/     # Reusable design primitives (Badge, CircularScore)
│   ├── lib/api.ts         # Typed API client
│   └── Dockerfile
├── sample_data/           # Downloadable MSME CSV templates
├── docs/                  # Architecture diagrams & 3-minute video demo script
├── docker-compose.yml     # Complete multi-container deployment
├── .env.example
├── LICENSE                # MIT License
└── README.md
```

---

## 📐 Core Mathematical & Deterministic Formulas

### 1. Days of Supply & Predictive Runout Date
$$\text{Days of Supply} = \frac{\max(\text{Current Usable Stock}, 0)}{\max(\text{Average Daily Demand} \times \text{Demand Multiplier}, 0.0001)}$$
$$\text{Estimated Stockout Date} = \text{Today} + \lfloor \text{Days of Supply} \rfloor$$

### 2. PO Double-Count Protected Replenishment
$$\text{Target Position} = (\text{Daily Demand} \times (\text{Lead Time} + \text{Safety Buffer})) + \text{Safety Stock}$$
$$\text{Effective Position} = \text{Current Stock} + \text{Pending Purchase Order Quantity}$$
$$\text{Recommended Reorder} = \max(0, \text{Target Position} - \text{Effective Position})$$

### 3. Capacity Revenue & Gross Margin at Risk
$$\text{Stockout Window (Days)} = \max(0, \text{Simulated Lead Time} - \text{Simulated Days of Supply})$$
$$\text{Unfulfilled Units} = \text{Stockout Window} \times \text{Simulated Daily Demand}$$
$$\text{Revenue at Risk} = \text{Unfulfilled Units} \times \text{Selling Price}$$
$$\text{Margin at Risk} = \text{Unfulfilled Units} \times \max(0, \text{Selling Price} - (\text{Unit Cost} \times \text{Price Hike Multiplier}))$$

### 4. 3-Way Reconciliation & Multi-Attribute Duplicate Matching
- **Line Arithmetic:** $\left| \sum (\text{Billed Quantity} \times \text{Billed Rate}) - \text{Invoice Total} \right| \le 0.05$
- **Rate Variance:** $\text{Billed Rate} > \text{PO Contract Rate} \implies \text{Price Mismatch Flag}$
- **Quantity Variance:** $\text{Billed Qty} > \text{PO Approved Qty} \implies \text{Overbill Mismatch Flag}$
- **Duplicate Matching:** Matching supplier ID and identical invoice number, OR matching supplier ID and identical total amount within a 30-day temporal window.

---

## 🖥️ Interactive Application Workspaces

| Workspace | Description | Key Capabilities |
|---|---|---|
| **Overview (Dashboard)** | High-density factory command deck | Dynamic SVG `CircularScore` (Composite Health Index 0–100), 4 KPI cards, **Priority Operational Risk Queue**, bar chart of critical supply buffers, and Nemotron AI insight panel. |
| **Business Failure Simulator** | Interactive stress-testing studio | Adjustable sliders for supplier delays, demand surges, payment defaults, and price hikes. Real-time recalculated revenue at risk and cheapest mitigations. |
| **AI Operations Co-pilot** | Conversational ERP advisor | Prompt pills, structured executive summaries, risk bullet points, citation chips linking to exact DB records (`STL-EN19-40`, `BS-INV-8491`), and an **Inspect Raw ERP Facts** drawer. |
| **Inventory Intelligence** | Stock runout & velocity table | Category/risk filtering, horizontal supply coverage bars, CSV export/import, and a slide-over **Product Detail Drawer** with unit economics. |
| **Invoice & PO Auditor** | 2-panel reconciliation studio | Left invoice stream with duplicate risk alerts; Right line-item audit ledger highlighting unauthorized price variance (₹ diff) with inline dispute/approval actions. |
| **Supplier Risk Monitor** | Vendor reliability workspace | Reliability scores (0–100), on-time delivery rates, delayed PO badges, affected components list, and operational exposure. |
| **Cash Flow Engine** | Treasury planning workspace | 14 & 30-day outlooks, Recharts area chart with zero-solvency reference boundary, deficit alert dates, and daily cash movement ledger. |
| **Action Center** | Operations governance inbox | Categorized items (*Critical, Needs Review, Approved, Completed*), impact exposure summaries, and immutable audit history. |

---

## 🚀 Quickstart & Local Installation

### Prerequisites
- Python 3.11+
- Node.js 18+ and npm
- Git

### 1. Clone & Configure
```bash
git clone https://github.com/your-username/kaamshield-ai.git
cd kaamshield-ai
cp .env.example .env
```

### 2. Launch Backend (FastAPI)
```bash
# Setup Python virtual environment
python -m venv venv

# Activate (Windows)
.\venv\Scripts\activate
# Activate (Linux / macOS)
source venv/bin/activate

# Install dependencies
pip install -r backend/requirements.txt

# Run FastAPI server
uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
```
*API is live at `http://localhost:8000`. Interactive OpenAPI documentation is at `http://localhost:8000/docs`.*

### 3. Launch Frontend (Next.js 14)
```bash
cd frontend
npm install
npm run dev
```
*Open `http://localhost:3000` (or `http://localhost:3005`). The app automatically pre-seeds realistic Indian MSME manufacturing data (Apex Precision Engineering Pvt. Ltd.) so you can explore immediately.*

---

## 🧪 Automated Verification & Test Suite

Run the automated backend test suite using Pytest:
```bash
# From repository root (with venv activated)
pytest -v backend/app/tests/test_all.py
```

### Test Coverage Results:
```text
backend/app/tests/test_all.py::test_stockout_date_calculation PASSED     [ 16%]
backend/app/tests/test_all.py::test_invoice_mismatch_detection PASSED    [ 33%]
backend/app/tests/test_all.py::test_duplicate_invoice_detection PASSED   [ 50%]
backend/app/tests/test_all.py::test_cash_flow_projection PASSED          [ 66%]
backend/app/tests/test_all.py::test_business_failure_simulator PASSED    [ 83%]
backend/app/tests/test_all.py::test_ai_provider_fallback PASSED          [100%]

======================= 6 passed in 2.50s =======================
```

---

## 🐳 Docker Deployment

Run the complete multi-container stack (FastAPI backend, Next.js frontend, and PostgreSQL):
```bash
docker-compose up --build
```
- **Frontend UI:** `http://localhost:3000`
- **Backend API:** `http://localhost:8000`
- **Interactive Swagger Docs:** `http://localhost:8000/docs`

---

## 🏆 Hackathon Evaluation Checklist

| Criteria | Implementation Status | Notes |
|---|---|---|
| **Eligible NVIDIA Model** | ✅ Verified | Connected to `nvidia/nemotron-3-super-120b-a12b` |
| **Nebius Token Factory** | ✅ Verified | Tested with `https://api.tokenfactory.nebius.com/v1/` |
| **Business Failure Simulator** | ✅ Verified | Interactive multi-variable shock studio with mitigations |
| **Grounded Intelligence** | ✅ Verified | Responses cite exact entity IDs; zero fabricated statistics |
| **Deterministic Fallback** | ✅ Verified | 100% uptime when API key is unconfigured or offline |
| **Invoice 3-Way Auditor** | ✅ Verified | Catches rate hikes, overbills, and duplicate submissions |
| **Automated Tests** | ✅ Verified | 6/6 automated Pytest test cases passing |
| **Production Build** | ✅ Verified | Next.js 14 production build compiles with 0 errors |
| **OSI-Approved License** | ✅ Verified | MIT License included |
| **No Secrets in Repo** | ✅ Verified | `.env.example` uses placeholders; `.gitignore` enforced |

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.
