from __future__ import annotations

import json
from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.entities import RecommendedAction
from app.services.queries import inventory_risks, invoice_audits, supplier_scores, cash_projection


def rebuild_actions(db: Session, workspace, today: date | None = None) -> list[RecommendedAction]:
    today = today or date.today()
    existing_open = db.scalars(
        select(RecommendedAction).where(
            RecommendedAction.workspace_id == workspace.id,
            RecommendedAction.status == "open",
        )
    ).all()
    for row in existing_open:
        db.delete(row)
    db.flush()

    created: list[RecommendedAction] = []

    def add(**kwargs) -> None:
        action = RecommendedAction(workspace_id=workspace.id, **kwargs)
        db.add(action)
        created.append(action)

    for risk in inventory_risks(db, workspace.id, today):
        if risk.risk_level in {"critical", "high"}:
            add(
                title=f"Approve replenishment for {risk.sku}",
                why=risk.explanation,
                domain="inventory",
                record_ids=json.dumps([risk.product_id]),
                priority=risk.risk_level,
                deadline=risk.expected_stockout_date,
                expected_benefit=f"Avoid modeled stockout of {risk.name}. Suggested qty {risk.suggested_reorder_qty}.",
                requires_approval=True,
            )

    for audit in invoice_audits(db, workspace.id):
        if not audit.has_issues:
            continue
        codes = {f.code for f in audit.flags}
        if "possible_duplicate_invoice" in codes or "repeated_invoice_number" in codes:
            add(
                title=f"Review possible duplicate invoice {audit.invoice_number}",
                why="; ".join(f.reason for f in audit.flags),
                domain="invoice",
                record_ids=json.dumps([audit.invoice_id]),
                priority="high",
                deadline=today + timedelta(days=2),
                expected_benefit="Prevent a potential overpayment. This is a review flag, not confirmed fraud.",
                requires_approval=True,
            )
        else:
            add(
                title=f"Resolve invoice discrepancy {audit.invoice_number}",
                why="; ".join(f.reason for f in audit.flags[:3]),
                domain="invoice",
                record_ids=json.dumps([audit.invoice_id]),
                priority="medium",
                deadline=today + timedelta(days=5),
                expected_benefit="Correct quantity/price mismatches before payment.",
                requires_approval=True,
            )

    for supplier in supplier_scores(db, workspace.id, today):
        if supplier.delayed_open_pos > 0:
            add(
                title=f"Contact {supplier.name} about delayed purchase orders",
                why=supplier.explanation,
                domain="supplier",
                record_ids=json.dumps([supplier.supplier_id] + supplier.affected_product_ids[:5]),
                priority="high",
                deadline=today + timedelta(days=1),
                expected_benefit=f"Open PO exposure currently {supplier.exposure_inr} INR.",
                requires_approval=True,
            )

    cash = cash_projection(db, workspace, 14, today)
    if cash.shortfall_dates:
        add(
            title="Investigate 14-day cash-flow shortfall",
            why=f"Projected balance turns negative on {cash.shortfall_dates[0].isoformat()} under stated payment assumptions.",
            domain="cash",
            record_ids=json.dumps([]),
            priority="critical",
            deadline=cash.shortfall_dates[0],
            expected_benefit=f"Additional cash required to stay non-negative: {abs(min(cash.min_balance, 0))} INR (projection).",
            requires_approval=True,
        )

    db.flush()
    return created
