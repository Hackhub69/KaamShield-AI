from datetime import date
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    workspace_name: str
    email: str


class ProductCreate(BaseModel):
    sku: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=200)
    category: str = ""
    supplier_id: str | None = None
    quantity_on_hand: Decimal = Decimal("0")
    reorder_threshold: Decimal = Decimal("0")
    safety_stock: Decimal = Decimal("0")
    avg_daily_demand: Decimal = Decimal("0")
    unit_cost: Decimal = Decimal("0")
    selling_price: Decimal = Decimal("0")
    lead_time_days: int = 7
    unit: str = "pcs"


class ProductUpdate(BaseModel):
    name: str | None = None
    category: str | None = None
    supplier_id: str | None = None
    quantity_on_hand: Decimal | None = None
    reorder_threshold: Decimal | None = None
    safety_stock: Decimal | None = None
    avg_daily_demand: Decimal | None = None
    unit_cost: Decimal | None = None
    selling_price: Decimal | None = None
    lead_time_days: int | None = None


class SupplierCreate(BaseModel):
    name: str
    city: str = ""
    category: str = ""
    stated_lead_time_days: int = 7
    notes: str = ""


class InvoiceImportLine(BaseModel):
    sku: str
    quantity: Decimal
    unit_price: Decimal
    line_total: Decimal | None = None
    description: str = ""


class InvoiceImport(BaseModel):
    invoice_number: str
    supplier_id: str
    purchase_order_id: str | None = None
    invoice_date: date
    due_date: date
    claimed_total: Decimal
    document_id: str = ""
    lines: list[InvoiceImportLine]


class ScenarioRequest(BaseModel):
    name: str = "Untitled scenario"
    supplier_delay_days: int = Field(default=0, ge=0, le=14)
    demand_change_pct: float = Field(default=0, ge=-80, le=100)
    supplier_price_increase_pct: float = Field(default=0, ge=0, le=50)
    customer_payment_delay_days: int = Field(default=0, ge=0, le=30)
    available_working_capital: Decimal | None = None
    alternative_lead_time_days: int | None = Field(default=None, ge=0, le=60)
    proposed_purchase_qty: Decimal = Decimal("0")
    proposed_purchase_product_id: str | None = None
    focus_supplier_id: str | None = None
    horizon_days: int = Field(default=14, ge=7, le=30)


class CopilotQuery(BaseModel):
    question: str = Field(min_length=3, max_length=2000)


class ActionStatusUpdate(BaseModel):
    status: str
    note: str = ""


class DemoLoadRequest(BaseModel):
    confirm_overwrite: bool = False
