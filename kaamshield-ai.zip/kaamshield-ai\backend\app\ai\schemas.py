from typing import Literal

from pydantic import BaseModel, Field


class CopilotRisk(BaseModel):
    title: str
    evidence_refs: list[str] = Field(default_factory=list)
    severity: Literal["critical", "high", "medium", "low", "unknown"] = "medium"


class CopilotAction(BaseModel):
    title: str
    rationale: str
    evidence_refs: list[str] = Field(default_factory=list)


class CopilotResponse(BaseModel):
    summary: str
    identified_risks: list[CopilotRisk] = Field(default_factory=list)
    supporting_evidence: list[str] = Field(default_factory=list)
    recommended_actions: list[CopilotAction] = Field(default_factory=list)
    priority: Literal["critical", "high", "medium", "low"] = "medium"
    estimated_impact: str | None = None
    confidence: Literal["low", "medium", "high"] = "medium"
    data_limitations: list[str] = Field(default_factory=list)
    unanswered_because_missing: list[str] = Field(default_factory=list)

    model_config = {"extra": "ignore"}


class AiStatus(BaseModel):
    status: Literal["connected", "configuration_required", "temporarily_unavailable"]
    model: str
    base_url_host: str
    configured: bool
    last_error: str | None = None
    attribution: str
    role: str
