"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { api, setToken } from "@/lib/api";
import { ErrorBanner } from "@/components/ui";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("demo@kaamshield.ai");
  const [password, setPassword] = useState("demo-pass-2026");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const result = await api<{ access_token: string }>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      setToken(result.access_token);
      router.push("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-5xl flex-col justify-center gap-10 px-6 py-12 lg:flex-row lg:items-center">
      <section className="flex-1">
        <p className="text-sm uppercase tracking-[0.2em] text-sky-300">NVIDIA × Nebius hackathon</p>
        <h1 className="mt-3 text-4xl font-semibold leading-tight">KaamShield AI</h1>
        <p className="mt-4 max-w-xl text-mute">
          Operations intelligence for Indian MSMEs. Stockouts, supplier delays, invoice mismatches, and cash shortfalls
          are calculated in code. NVIDIA Nemotron on Nebius Token Factory explains the evidence — it does not invent the numbers.
        </p>
        <ul className="mt-6 space-y-2 text-sm text-mute">
          <li>Deterministic inventory, invoice, and cash-flow engines</li>
          <li>Business Failure Simulator with baseline vs scenario comparison</li>
          <li>Evidence-grounded copilot with fallback when the model is offline</li>
        </ul>
      </section>
      <form onSubmit={onSubmit} className="card w-full max-w-md space-y-4">
        <h2 className="text-lg font-medium">Sign in</h2>
        <p className="text-sm text-mute">
          Demo workspace: <span className="font-mono text-ink">demo@kaamshield.ai</span> /{" "}
          <span className="font-mono text-ink">demo-pass-2026</span>
        </p>
        {error ? <ErrorBanner message={error} /> : null}
        <label className="block text-sm">
          Email
          <input className="input mt-1" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </label>
        <label className="block text-sm">
          Password
          <input className="input mt-1" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </label>
        <button className="btn-primary w-full" type="submit" disabled={busy}>
          {busy ? "Signing in…" : "Enter workspace"}
        </button>
      </form>
    </div>
  );
}
