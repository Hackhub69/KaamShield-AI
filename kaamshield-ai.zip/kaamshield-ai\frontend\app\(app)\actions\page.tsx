"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Badge, EmptyState, ErrorBanner, LoadingState, SuccessBanner } from "@/components/ui";
import type { ActionRow } from "@/lib/types";

export default function ActionsPage() {
  const [rows, setRows] = useState<ActionRow[]>([]);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [loading, setLoading] = useState(true);
  const [confirmReset, setConfirmReset] = useState(false);

  async function load() {
    try {
      setRows(await api<ActionRow[]>("/api/actions"));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load actions");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function setStatus(id: string, status: string) {
    try {
      await api(`/api/actions/${id}/status`, { method: "POST", body: JSON.stringify({ status, note: `Marked ${status}` }) });
      setOk(`Action ${status}. No payment or inventory mutation was executed.`);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Update failed");
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Action center</h1>
          <p className="text-sm text-mute">Prioritized work from calculated risks. Status changes are audited. Financial transactions are never auto-executed.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            className="btn-primary"
            type="button"
            onClick={async () => {
              await api("/api/actions/rebuild", { method: "POST" });
              setOk("Actions rebuilt from current calculations.");
              await load();
            }}
          >
            Rebuild from calculations
          </button>
          <button
            className="btn-ghost"
            type="button"
            onClick={async () => {
              if (!confirmReset) {
                setConfirmReset(true);
                setOk("Click again to confirm overwriting the demonstration workspace sample data.");
                return;
              }
              await api("/api/demo/load", { method: "POST", body: JSON.stringify({ confirm_overwrite: true }) });
              setConfirmReset(false);
              setOk("Demo data reset for the demonstration workspace.");
              await load();
            }}
          >
            {confirmReset ? "Confirm reset demo data" : "Reset demo data"}
          </button>
        </div>
      </div>
      {error ? <ErrorBanner message={error} /> : null}
      {ok ? <SuccessBanner message={ok} /> : null}
      {loading ? (
        <LoadingState />
      ) : rows.length === 0 ? (
        <EmptyState title="No actions" body="Rebuild from inventory, invoice, supplier, and cash calculations." />
      ) : (
        <div className="space-y-3">
          {rows.map((row) => (
            <article key={row.id} className="card space-y-3">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <h2 className="font-medium">{row.title}</h2>
                  <p className="text-sm text-mute">{row.why}</p>
                </div>
                <Badge level={row.priority}>{row.priority}</Badge>
              </div>
              <p className="text-xs text-mute">
                Domain {row.domain} · status {row.status} · deadline {row.deadline || "none"} · approval {row.requires_approval ? "required" : "not required"}
              </p>
              <p className="text-sm">{row.expected_benefit}</p>
              <p className="text-xs font-mono text-mute">Records: {row.record_ids.join(", ") || "n/a"}</p>
              <div className="flex flex-wrap gap-2">
                {["reviewed", "dismissed", "completed"].map((status) => (
                  <button key={status} className="btn-ghost" type="button" onClick={() => setStatus(row.id, status)} disabled={row.status === status}>
                    Mark {status}
                  </button>
                ))}
              </div>
              {row.events.length ? (
                <ul className="border-t border-white/5 pt-2 text-xs text-mute">
                  {row.events.map((event, idx) => (
                    <li key={idx}>
                      {event.created_at}: {event.actor} {event.from_status} → {event.to_status} {event.note}
                    </li>
                  ))}
                </ul>
              ) : null}
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
