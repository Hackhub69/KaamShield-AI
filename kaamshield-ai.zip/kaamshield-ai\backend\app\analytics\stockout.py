from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from typing import Any


ZERO = Decimal("0")


def _dec(value: Any) -> Decimal:
    if value is None:
        return ZERO
    return Decimal(str(value))


def days_of_supply(quantity_on_hand: Any, avg_daily_demand: Any) -> Decimal | None:
    qty = _dec(quantity_on_hand)
    demand = _dec(avg_daily_demand)
    if demand <= 0:
        return None
    if qty < 0:
        qty = ZERO
    return (qty / demand).quantize(Decimal("0.01"))


def estimated_stockout_date(today: date, quantity_on_hand: Any, avg_daily_demand: Any) -> date | None:
    dos = days_of_supply(quantity_on_hand, avg_daily_demand)
    if dos is None:
        return None
    return today + timedelta(days=int(dos))


def demand_during_lead_time(avg_daily_demand: Any, lead_time_days: int | None) -> Decimal | None:
    demand = _dec(avg_daily_demand)
    if demand <= 0 or lead_time_days is None or lead_time_days < 0:
        return None
    return (demand * Decimal(lead_time_days)).quantize(Decimal("0.01"))


def suggested_reorder_quantity(
    *,
    quantity_on_hand: Any,
    avg_daily_demand: Any,
    lead_time_days: int | None,
    safety_stock: Any = 0,
    pending_po_quantity: Any = 0,
    protection_days: int | None = None,
) -> Decimal | None:
    demand = _dec(avg_daily_demand)
    if demand <= 0:
        return None
    if lead_time_days is None or lead_time_days < 0:
        return None
    cover = protection_days if protection_days is not None else lead_time_days
    if cover < 0:
        return None
    inventory_position = _dec(quantity_on_hand) + _dec(pending_po_quantity)
    required = demand * Decimal(cover) + _dec(safety_stock)
    qty = required - inventory_position
    if qty < 0:
        return ZERO
    return qty.quantize(Decimal("0.01"))


def risk_level(*, stockout: date | None, today: date, lead_time_days: int | None, quantity_on_hand: Any, reorder_threshold: Any) -> str:
    qty = _dec(quantity_on_hand)
    threshold = _dec(reorder_threshold)
    if qty <= 0:
        return "critical"
    if stockout is None:
        if threshold > 0 and qty <= threshold:
            return "medium"
        return "unknown"
    days_left = (stockout - today).days
    lead = lead_time_days if lead_time_days is not None and lead_time_days >= 0 else 7
    if days_left <= 0:
        return "critical"
    if days_left <= min(7, lead):
        return "critical"
    if days_left <= 14:
        return "high"
    if days_left <= 30 or (threshold > 0 and qty <= threshold):
        return "medium"
    return "low"


def margin_at_risk(avg_daily_demand: Any, selling_price: Any, unit_cost: Any, stockout_days: int) -> Decimal:
    if stockout_days <= 0:
        return ZERO
    demand = _dec(avg_daily_demand)
    if demand <= 0:
        return ZERO
    margin = _dec(selling_price) - _dec(unit_cost)
    if margin <= 0:
        return ZERO
    return (demand * Decimal(stockout_days) * margin).quantize(Decimal("0.01"))


@dataclass
class InventoryRisk:
    product_id: str
    sku: str
    name: str
    quantity_on_hand: Decimal
    reorder_threshold: Decimal
    avg_daily_demand: Decimal
    lead_time_days: int | None
    unit_cost: Decimal
    selling_price: Decimal
    pending_po_quantity: Decimal
    days_of_supply: Decimal | None
    expected_stockout_date: date | None
    suggested_reorder_qty: Decimal | None
    demand_during_lead_time: Decimal | None
    risk_level: str
    explanation: str
    inventory_value: Decimal
    notes: list[str]


def analyze_product(
    *,
    product_id: str,
    sku: str,
    name: str,
    quantity_on_hand: Any,
    reorder_threshold: Any,
    avg_daily_demand: Any,
    lead_time_days: int | None,
    unit_cost: Any,
    selling_price: Any = 0,
    safety_stock: Any = 0,
    pending_po_quantity: Any = 0,
    today: date,
) -> InventoryRisk:
    notes: list[str] = []
    qty = _dec(quantity_on_hand)
    demand = _dec(avg_daily_demand)
    cost = _dec(unit_cost)
    if demand <= 0:
        notes.append("Average daily demand is zero or missing; stockout date cannot be estimated.")
    if lead_time_days is None:
        notes.append("Supplier lead time is unavailable.")
    elif lead_time_days < 0:
        notes.append("Negative lead time was ignored.")
        lead_time_days = None
    if qty < 0:
        notes.append("Negative on-hand quantity was treated as zero for days-of-supply.")

    dos = days_of_supply(qty, demand)
    stockout = estimated_stockout_date(today, qty, demand)
    dlt = demand_during_lead_time(demand, lead_time_days)
    reorder = suggested_reorder_quantity(
        quantity_on_hand=qty,
        avg_daily_demand=demand,
        lead_time_days=lead_time_days,
        safety_stock=safety_stock,
        pending_po_quantity=pending_po_quantity,
        protection_days=lead_time_days,
    )
    level = risk_level(
        stockout=stockout,
        today=today,
        lead_time_days=lead_time_days,
        quantity_on_hand=qty,
        reorder_threshold=reorder_threshold,
    )
    explanation_parts = []
    if dos is not None:
        explanation_parts.append(f"Days of supply = {qty} / {demand} = {dos}.")
    if stockout:
        explanation_parts.append(f"Estimated stockout date is {stockout.isoformat()}.")
    if dlt is not None:
        explanation_parts.append(f"Expected demand during lead time = {demand} × {lead_time_days} = {dlt}.")
    if reorder is not None:
        explanation_parts.append(
            f"Suggested reorder = demand during lead time + safety stock − (on-hand + pending POs) = {reorder}."
        )
    explanation_parts.extend(notes)
    if not explanation_parts:
        explanation_parts.append("Insufficient data for a stockout estimate.")

    return InventoryRisk(
        product_id=product_id,
        sku=sku,
        name=name,
        quantity_on_hand=qty,
        reorder_threshold=_dec(reorder_threshold),
        avg_daily_demand=demand,
        lead_time_days=lead_time_days,
        unit_cost=cost,
        selling_price=_dec(selling_price),
        pending_po_quantity=_dec(pending_po_quantity),
        days_of_supply=dos,
        expected_stockout_date=stockout,
        suggested_reorder_qty=reorder,
        demand_during_lead_time=dlt,
        risk_level=level,
        explanation=" ".join(explanation_parts),
        inventory_value=(qty * cost).quantize(Decimal("0.01")),
        notes=notes,
    )
