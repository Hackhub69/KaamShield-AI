from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.analytics.cashflow import project_cash
from app.analytics.reconciliation import compare_invoice_to_po, find_duplicate_candidates
from app.analytics.stockout import analyze_product
from app.analytics.supplier_risk import score_supplier
from app.models.entities import (
    CashFlowEntry,
    GoodsReceipt,
    Invoice,
    Product,
    PurchaseOrder,
    Receivable,
    RecommendedAction,
    Supplier,
    Workspace,
)


def pending_po_quantities(db: Session, workspace_id: str) -> dict[str, Decimal]:
    pending: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    orders = db.scalars(
        select(PurchaseOrder)
        .options(selectinload(PurchaseOrder.lines))
        .where(PurchaseOrder.workspace_id == workspace_id, PurchaseOrder.status.in_(["open", "partial", "delayed"]))
    ).all()
    for po in orders:
        for line in po.lines:
            pending[line.product_id] += Decimal(line.quantity)
    return pending


def inventory_risks(db: Session, workspace_id: str, today: date | None = None):
    today = today or date.today()
    pending = pending_po_quantities(db, workspace_id)
    products = db.scalars(select(Product).where(Product.workspace_id == workspace_id)).all()
    return [
        analyze_product(
            product_id=p.id,
            sku=p.sku,
            name=p.name,
            quantity_on_hand=p.quantity_on_hand,
            reorder_threshold=p.reorder_threshold,
            avg_daily_demand=p.avg_daily_demand,
            lead_time_days=p.lead_time_days,
            unit_cost=p.unit_cost,
            selling_price=p.selling_price,
            safety_stock=p.safety_stock,
            pending_po_quantity=pending.get(p.id, Decimal("0")),
            today=today,
        )
        for p in products
    ]


def invoice_audits(db: Session, workspace_id: str):
    invoices = db.scalars(
        select(Invoice)
        .options(
            selectinload(Invoice.lines),
            selectinload(Invoice.purchase_order).selectinload(PurchaseOrder.lines),
            selectinload(Invoice.purchase_order)
            .selectinload(PurchaseOrder.receipts)
            .selectinload(GoodsReceipt.lines),
        )
        .where(Invoice.workspace_id == workspace_id)
    ).all()
    products = {p.id: p for p in db.scalars(select(Product).where(Product.workspace_id == workspace_id)).all()}
    results = []
    snapshot = []
    for inv in invoices:
        po_lines = None
        po_supplier = None
        receipt_qty: dict | None = None
        if inv.purchase_order:
            po_supplier = inv.purchase_order.supplier_id
            po_lines = []
            for line in inv.purchase_order.lines:
                prod = products.get(line.product_id)
                po_lines.append(
                    {
                        "sku": prod.sku if prod else "",
                        "quantity": line.quantity,
                        "unit_price": line.unit_price,
                    }
                )
            if inv.purchase_order.receipts:
                receipt_qty = {}
                for rec in inv.purchase_order.receipts:
                    for line in rec.lines:
                        prod = products.get(line.product_id)
                        sku = prod.sku if prod else ""
                        if not sku:
                            continue
                        receipt_qty[sku] = receipt_qty.get(sku, Decimal("0")) + Decimal(str(line.quantity))
        inv_lines = []
        for line in inv.lines:
            sku = line.sku
            if not sku and line.product_id and line.product_id in products:
                sku = products[line.product_id].sku
            inv_lines.append(
                {
                    "sku": sku,
                    "quantity": line.quantity,
                    "unit_price": line.unit_price,
                    "line_total": line.line_total,
                }
            )
        result = compare_invoice_to_po(
            invoice_id=inv.id,
            invoice_number=inv.invoice_number,
            invoice_supplier_id=inv.supplier_id,
            po_supplier_id=po_supplier,
            claimed_total=inv.claimed_total,
            invoice_lines=inv_lines,
            po_lines=po_lines,
            receipt_qty_by_sku=receipt_qty,
        )
        results.append(result)
        snapshot.append(
            {
                "id": inv.id,
                "supplier_id": inv.supplier_id,
                "invoice_number": inv.invoice_number,
                "claimed_total": inv.claimed_total,
                "invoice_date": inv.invoice_date,
                "document_id": inv.document_id,
            }
        )
    dupes = find_duplicate_candidates(snapshot)
    by_id = {r.invoice_id: r for r in results}
    for flag in dupes:
        if flag.invoice_id in by_id:
            by_id[flag.invoice_id].flags.append(flag)
    return results


def supplier_scores(db: Session, workspace_id: str, today: date | None = None):
    today = today or date.today()
    suppliers = db.scalars(select(Supplier).where(Supplier.workspace_id == workspace_id)).all()
    pos = (
        db.query(PurchaseOrder)
        .options(selectinload(PurchaseOrder.receipts), selectinload(PurchaseOrder.lines))
        .filter(PurchaseOrder.workspace_id == workspace_id)
        .all()
    )
    by_supplier: dict[str, list[PurchaseOrder]] = defaultdict(list)
    for po in pos:
        by_supplier[po.supplier_id].append(po)
    products = db.scalars(select(Product).where(Product.workspace_id == workspace_id)).all()
    products_by_supplier: dict[str, list[Product]] = defaultdict(list)
    for p in products:
        if p.supplier_id:
            products_by_supplier[p.supplier_id].append(p)

    scores = []
    for supplier in suppliers:
        receipts = []
        open_pos = []
        delayed_exposure = Decimal("0")
        affected = set()
        for po in by_supplier.get(supplier.id, []):
            if po.status in {"open", "partial", "delayed"}:
                open_pos.append({"promised_on": po.promised_on, "status": po.status})
                for line in po.lines:
                    affected.add(line.product_id)
                    delayed_exposure += Decimal(line.quantity) * Decimal(line.unit_price)
            for receipt in po.receipts:
                receipts.append((po.promised_on, receipt.received_on))
            if po.received_on:
                receipts.append((po.promised_on, po.received_on))
        for product in products_by_supplier.get(supplier.id, []):
            affected.add(product.id)
        scores.append(
            score_supplier(
                supplier_id=supplier.id,
                name=supplier.name,
                stated_lead_time_days=supplier.stated_lead_time_days,
                receipts=receipts,
                open_pos=open_pos,
                affected_product_ids=list(affected),
                exposure_inr=delayed_exposure,
                today=today,
                uses_sample_history=supplier.sample_data,
            )
        )
    return scores


def cash_inputs(db: Session, workspace_id: str, today: date, payment_delay_days: int = 0):
    inflows = []
    for rec in db.scalars(select(Receivable).where(Receivable.workspace_id == workspace_id)).all():
        scheduled = rec.expected_on or rec.due_on
        overdue = rec.due_on < today and rec.status == "open"
        if payment_delay_days:
            scheduled = scheduled + timedelta(days=payment_delay_days)
        inflows.append(
            {
                "amount": rec.amount,
                "scheduled_on": scheduled,
                "overdue": overdue and rec.expected_on is None,
                "label": rec.invoice_number,
                "note": rec.payment_assumption,
            }
        )
    outflows = []
    invoices = db.scalars(select(Invoice).where(Invoice.workspace_id == workspace_id, Invoice.status != "paid")).all()
    for inv in invoices:
        outflows.append(
            {
                "amount": inv.claimed_total,
                "scheduled_on": inv.due_date,
                "overdue": False,
                "label": inv.invoice_number,
                "supplier_id": inv.supplier_id,
                "note": "Unpaid supplier invoice scheduled on due date.",
            }
        )
    for entry in db.scalars(select(CashFlowEntry).where(CashFlowEntry.workspace_id == workspace_id)).all():
        row = {
            "amount": abs(entry.amount),
            "scheduled_on": entry.entry_date,
            "overdue": False,
            "label": entry.description,
            "note": entry.category,
        }
        if entry.direction == "in":
            inflows.append(row)
        else:
            outflows.append(row)
    return inflows, outflows


def cash_projection(db: Session, workspace: Workspace, horizon: int, today: date | None = None):
    today = today or date.today()
    inflows, outflows = cash_inputs(db, workspace.id, today)
    return project_cash(
        opening_cash=workspace.opening_cash,
        today=today,
        horizon_days=horizon,
        inflows=inflows,
        outflows=outflows,
    )


def dashboard_metrics(db: Session, workspace: Workspace, today: date | None = None) -> dict:
    today = today or date.today()
    risks = inventory_risks(db, workspace.id, today)
    audits = invoice_audits(db, workspace.id)
    suppliers = supplier_scores(db, workspace.id, today)
    cash14 = cash_projection(db, workspace, 14, today)
    cash30 = cash_projection(db, workspace, 30, today)
    actions = db.scalars(
        select(RecommendedAction)
        .where(RecommendedAction.workspace_id == workspace.id, RecommendedAction.status == "open")
        .order_by(RecommendedAction.created_at.desc())
    ).all()

    inventory_value = sum((r.inventory_value for r in risks), Decimal("0"))
    low_stock = sum(1 for r in risks if r.quantity_on_hand <= r.reorder_threshold)
    stockout_7 = sum(1 for r in risks if r.expected_stockout_date and (r.expected_stockout_date - today).days <= 7)
    stockout_14 = sum(1 for r in risks if r.expected_stockout_date and (r.expected_stockout_date - today).days <= 14)
    recs = db.scalars(select(Receivable).where(Receivable.workspace_id == workspace.id, Receivable.status == "open")).all()
    receivables = sum((r.amount for r in recs), Decimal("0"))
    payables = sum((a.claimed_total for a in db.scalars(select(Invoice).where(Invoice.workspace_id == workspace.id, Invoice.status != "paid")).all()), Decimal("0"))
    discrepancy_count = sum(1 for a in audits if a.has_issues)
    supplier_delay = sum(1 for s in suppliers if s.delayed_open_pos > 0)
    exposure = sum((s.exposure_inr for s in suppliers), Decimal("0"))
    exposure += sum(
        (r.unit_cost * r.avg_daily_demand * Decimal("7") for r in risks if r.risk_level in {"critical", "high"} and r.avg_daily_demand > 0),
        Decimal("0"),
    )

    return {
        "workspace": {"id": workspace.id, "name": workspace.name, "city": workspace.city, "currency": workspace.currency, "is_demo": workspace.is_demo},
        "as_of": today.isoformat(),
        "total_inventory_value": str(inventory_value.quantize(Decimal("0.01"))),
        "low_stock_products": low_stock,
        "predicted_stockouts_7d": stockout_7,
        "predicted_stockouts_14d": stockout_14,
        "outstanding_receivables": str(receivables.quantize(Decimal("0.01"))),
        "outstanding_payables": str(payables.quantize(Decimal("0.01"))),
        "invoice_discrepancies": discrepancy_count,
        "suppliers_with_delays": supplier_delay,
        "estimated_operational_exposure": str(exposure.quantize(Decimal("0.01"))),
        "cash_14d_min_balance": str(cash14.min_balance),
        "cash_14d_shortfalls": [d.isoformat() for d in cash14.shortfall_dates],
        "cash_30d_min_balance": str(cash30.min_balance),
        "open_actions": [
            {"id": a.id, "title": a.title, "priority": a.priority, "domain": a.domain}
            for a in actions[:8]
        ],
        "empty": len(risks) == 0,
    }


def evidence_package(db: Session, workspace: Workspace, extra: dict | None = None) -> dict:
    today = date.today()
    risks = inventory_risks(db, workspace.id, today)
    audits = invoice_audits(db, workspace.id)
    suppliers = supplier_scores(db, workspace.id, today)
    cash = cash_projection(db, workspace, 14, today)
    flags = []
    for audit in audits:
        for flag in audit.flags:
            flags.append(
                {
                    "invoice_id": flag.invoice_id,
                    "related_invoice_id": flag.related_invoice_id,
                    "code": flag.code,
                    "reason": flag.reason,
                    "original": flag.original,
                    "expected": flag.expected,
                    "difference": flag.difference,
                }
            )
    payload = {
        "workspace_id": workspace.id,
        "as_of": today.isoformat(),
        "inventory_risks": [
            {
                "product_id": r.product_id,
                "sku": r.sku,
                "name": r.name,
                "risk_level": r.risk_level,
                "expected_stockout_date": r.expected_stockout_date.isoformat() if r.expected_stockout_date else None,
                "suggested_reorder_qty": str(r.suggested_reorder_qty) if r.suggested_reorder_qty is not None else None,
                "explanation": r.explanation,
            }
            for r in sorted(risks, key=lambda x: x.risk_level)[:20]
        ],
        "invoice_flags": flags[:20],
        "suppliers": [
            {
                "supplier_id": s.supplier_id,
                "name": s.name,
                "reliability_score": str(s.reliability_score) if s.reliability_score is not None else None,
                "delayed_open_pos": s.delayed_open_pos,
                "exposure_inr": str(s.exposure_inr),
                "uses_sample_history": s.uses_sample_history,
            }
            for s in suppliers
        ],
        "cash_14d": {
            "opening_cash": str(cash.opening_cash),
            "min_balance": str(cash.min_balance),
            "shortfall_dates": [d.isoformat() for d in cash.shortfall_dates],
            "assumptions": cash.assumptions,
        },
        "calculated_impact": f"Estimated operational exposure is included in dashboard metrics as of {today.isoformat()}.",
    }
    if extra:
        payload.update(extra)
    return payload
