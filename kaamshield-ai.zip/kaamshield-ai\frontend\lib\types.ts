export type AiStatus = {
  status: "connected" | "configuration_required" | "temporarily_unavailable";
  model: string;
  base_url_host: string;
  configured: boolean;
  last_error: string | null;
  attribution: string;
  role: string;
};

export type Dashboard = {
  workspace: { id: string; name: string; city: string; currency: string; is_demo: boolean };
  as_of: string;
  total_inventory_value: string;
  low_stock_products: number;
  predicted_stockouts_7d: number;
  predicted_stockouts_14d: number;
  outstanding_receivables: string;
  outstanding_payables: string;
  invoice_discrepancies: number;
  suppliers_with_delays: number;
  estimated_operational_exposure: string;
  cash_14d_min_balance: string;
  cash_14d_shortfalls: string[];
  cash_30d_min_balance: string;
  open_actions: { id: string; title: string; priority: string; domain: string }[];
  empty: boolean;
};

export type InventoryRow = {
  id: string;
  sku: string;
  name: string;
  category: string;
  supplier_id: string | null;
  quantity_on_hand: string;
  reorder_threshold: string;
  safety_stock: string;
  avg_daily_demand: string;
  unit_cost: string;
  selling_price: string;
  lead_time_days: number;
  days_of_supply: string | null;
  expected_stockout_date: string | null;
  suggested_reorder_qty: string | null;
  demand_during_lead_time: string | null;
  risk_level: string;
  explanation: string;
  pending_po_quantity: string;
  sample_data: boolean;
};

export type SupplierRow = {
  id: string;
  name: string;
  city: string;
  category: string;
  stated_lead_time_days: number;
  sample_data: boolean;
  on_time_rate: string | null;
  avg_actual_lead_days: string | null;
  open_pos: number;
  delayed_open_pos: number;
  affected_product_ids: string[];
  reliability_score: string | null;
  exposure_inr: string;
  explanation: string;
};

export type InvoiceRow = {
  id: string;
  invoice_number: string;
  supplier_id: string;
  purchase_order_id: string | null;
  invoice_date: string;
  due_date: string;
  status: string;
  claimed_total: string;
  computed_total: string | null;
  sample_data: boolean;
  flags: {
    code: string;
    reason: string;
    field: string;
    original: string;
    expected: string;
    difference: string;
    related_invoice_id?: string | null;
  }[];
  lines: { sku: string; quantity: string; unit_price: string; line_total: string }[];
};

export type ActionRow = {
  id: string;
  title: string;
  why: string;
  domain: string;
  record_ids: string[];
  priority: string;
  deadline: string | null;
  expected_benefit: string;
  requires_approval: boolean;
  status: string;
  events: { actor: string; from_status: string; to_status: string; note: string; created_at: string | null }[];
};
