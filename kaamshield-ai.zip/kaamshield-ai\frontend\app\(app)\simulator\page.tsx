"use client";

import { FormEvent, useEffect, useState } from "react";
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api, inr } from "@/lib/api";
import { Badge, ErrorBanner, LoadingState, Metric, SuccessBanner } from "@/components/ui";
import type { InventoryRow, SupplierRow } from "@/lib/types";

type SimResult = {
  scenario_id: string;
  comparison: {
    products_affected: {
      product_id: string;
      sku: string;
      name: string;
      baseline_stockout: string | null;
      simulated_stockout: string | null;
      baseline_risk: string;
      simulated_risk: string;
      margin_at_risk_inr: string;
    }[];
    estimated_margin_at_risk_inr: string;
    additional_cash_required_inr: string;
    baseline_shortfall_dates: string[];
    simulated_shortfall_dates: string[];
    uncertainty: string;
  };
  baseline_cash: { daily: { day: string; balance: string }[]; min_balance: string };
  simulated_cash: { daily: { day: string; balance: string }[]; min_balance: string };
  mitigations: { product_id: string; sku: string; action: string; suggested_qty: string; estimated_buy_inr: string }[];
  uncertainty: string;
};

export default function SimulatorPage() {
  const [suppliers, setSuppliers] = useState<SupplierRow[]>([]);
  const [products, setProducts] = useState<InventoryRow[]>([]);
  const [result, setResult] = useState<SimResult | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    name: "Largest supplier delayed 5 days",
    supplier_delay_days: "5",
    demand_change_pct: "0",
    supplier_price_increase_pct: "0",
    customer_payment_delay_days: "0",
    alternative_lead_time_days: "",
    proposed_purchase_qty: "0",
    proposed_purchase_product_id: "",
    focus_supplier_id: "",
    horizon_days: "14",
  });

  useEffect(() => {
    Promise.all([api<SupplierRow[]>("/api/suppliers"), api<InventoryRow[]>("/api/inventory")])
      .then(([s, p]) => {
        setSuppliers(s);
        setProducts(p);
        const delayed = s.find((row) => row.delayed_open_pos > 0) || s[0];
        if (delayed) setForm((prev) => ({ ...prev, focus_supplier_id: delayed.id }));
      })
      .catch((err) => setError(err.message));
  }, []);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const payload = {
        name: form.name,
        supplier_delay_days: Number(form.supplier_delay_days),
        demand_change_pct: Number(form.demand_change_pct),
        supplier_price_increase_pct: Number(form.supplier_price_increase_pct),
        customer_payment_delay_days: Number(form.customer_payment_delay_days),
        alternative_lead_time_days: form.alternative_lead_time_days ? Number(form.alternative_lead_time_days) : null,
        proposed_purchase_qty: Number(form.proposed_purchase_qty),
        proposed_purchase_product_id: form.proposed_purchase_product_id || null,
        focus_supplier_id: form.focus_supplier_id || null,
        horizon_days: Number(form.horizon_days),
      };
      setResult(await api<SimResult>("/api/simulator", { method: "POST", body: JSON.stringify(payload) }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Simulation failed");
    } finally {
      setBusy(false);
    }
  }

  const chart =
    result?.baseline_cash.daily.map((d, i) => ({
      day: d.day.slice(5),
      baseline: Number(d.balance),
      simulated: Number(result.simulated_cash.daily[i]?.balance ?? d.balance),
    })) ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Business Failure Simulator</h1>
        <p className="text-sm text-mute">
          Recalculates inventory and cash with your assumptions. Margin at risk is a modeled contribution-margin estimate, not a guaranteed loss.
        </p>
      </div>
      {error ? <ErrorBanner message={error} /> : null}
      <form className="card grid gap-3 md:grid-cols-3" onSubmit={onSubmit}>
        <input className="input md:col-span-3" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <label className="text-sm">
          Supplier delay (0–14 days)
          <input className="input mt-1" type="number" min={0} max={14} value={form.supplier_delay_days} onChange={(e) => setForm({ ...form, supplier_delay_days: e.target.value })} />
        </label>
        <label className="text-sm">
          Demand change %
          <input className="input mt-1" type="number" min={-80} max={100} value={form.demand_change_pct} onChange={(e) => setForm({ ...form, demand_change_pct: e.target.value })} />
        </label>
        <label className="text-sm">
          Supplier price increase %
          <input className="input mt-1" type="number" min={0} max={50} value={form.supplier_price_increase_pct} onChange={(e) => setForm({ ...form, supplier_price_increase_pct: e.target.value })} />
        </label>
        <label className="text-sm">
          Customer payment delay (days)
          <input className="input mt-1" type="number" min={0} max={30} value={form.customer_payment_delay_days} onChange={(e) => setForm({ ...form, customer_payment_delay_days: e.target.value })} />
        </label>
        <label className="text-sm">
          Alternative lead time
          <input className="input mt-1" value={form.alternative_lead_time_days} onChange={(e) => setForm({ ...form, alternative_lead_time_days: e.target.value })} placeholder="optional" />
        </label>
        <label className="text-sm">
          Focus supplier
          <select className="input mt-1" value={form.focus_supplier_id} onChange={(e) => setForm({ ...form, focus_supplier_id: e.target.value })}>
            <option value="">All suppliers</option>
            {suppliers.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </label>
        <label className="text-sm">
          Proposed purchase SKU
          <select className="input mt-1" value={form.proposed_purchase_product_id} onChange={(e) => setForm({ ...form, proposed_purchase_product_id: e.target.value })}>
            <option value="">None</option>
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.sku}
              </option>
            ))}
          </select>
        </label>
        <label className="text-sm">
          Proposed purchase qty
          <input className="input mt-1" value={form.proposed_purchase_qty} onChange={(e) => setForm({ ...form, proposed_purchase_qty: e.target.value })} />
        </label>
        <button className="btn-primary md:col-span-3 w-fit" type="submit" disabled={busy}>
          {busy ? "Recalculating…" : "Run scenario"}
        </button>
      </form>
      {busy && !result ? <LoadingState /> : null}
      {result ? (
        <>
          <SuccessBanner message={`Scenario stored as ${result.scenario_id}. Baseline vs changed results below.`} />
          <div className="grid gap-4 md:grid-cols-3">
            <Metric label="Modeled margin at risk" value={inr(result.comparison.estimated_margin_at_risk_inr)} hint="Not a booked loss" />
            <Metric label="Additional cash to stay non-negative" value={inr(result.comparison.additional_cash_required_inr)} />
            <Metric
              label="Products affected"
              value={String(result.comparison.products_affected.length)}
              hint={`Simulated shortfalls: ${result.comparison.simulated_shortfall_dates.join(", ") || "none"}`}
            />
          </div>
          <div className="card h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chart}>
                <CartesianGrid stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="day" stroke="#94A3B8" />
                <YAxis stroke="#94A3B8" />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="baseline" stroke="#94A3B8" dot={false} name="Baseline cash" />
                <Line type="monotone" dataKey="simulated" stroke="#F59E0B" dot={false} name="Simulated cash" />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th>SKU</th>
                  <th>Baseline stockout</th>
                  <th>Simulated stockout</th>
                  <th>Risk change</th>
                  <th>Margin at risk</th>
                </tr>
              </thead>
              <tbody>
                {result.comparison.products_affected.map((row) => (
                  <tr key={row.product_id}>
                    <td>
                      {row.sku}
                      <div className="text-xs text-mute">{row.name}</div>
                    </td>
                    <td className="font-mono">{row.baseline_stockout || "—"}</td>
                    <td className="font-mono">{row.simulated_stockout || "—"}</td>
                    <td>
                      <Badge level={row.simulated_risk}>
                        {row.baseline_risk} → {row.simulated_risk}
                      </Badge>
                    </td>
                    <td className="font-mono">{inr(row.margin_at_risk_inr)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <section className="card">
            <h2 className="font-medium">Cheapest feasible mitigations from the engine</h2>
            <ul className="mt-2 space-y-2 text-sm">
              {result.mitigations.map((item) => (
                <li key={item.product_id}>
                  {item.sku}: buy {item.suggested_qty} (~{inr(item.estimated_buy_inr)}). {item.action}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-mute">{result.uncertainty}</p>
          </section>
        </>
      ) : null}
    </div>
  );
}
