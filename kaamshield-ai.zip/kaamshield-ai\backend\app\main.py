from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address
from sqlalchemy import inspect
from starlette.middleware.base import BaseHTTPMiddleware

from app.api.routes import public, router
from app.core.config import get_settings
from app.core.database import Base, engine, SessionLocal
from app.models import entities  # noqa: F401
from app.services.demo import ensure_demo_workspace

settings = get_settings()
limiter = Limiter(key_func=get_remote_address, default_limits=["120/minute"])


class LimitBodyMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > 5 * 1024 * 1024:
            return JSONResponse({"detail": "Request too large"}, status_code=413)
        return await call_next(request)


def _ensure_schema() -> None:
    Base.metadata.create_all(bind=engine)
    inspector = inspect(engine)
    if "workspaces" not in inspector.get_table_names():
        raise RuntimeError("Database schema failed to initialize")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    _ensure_schema()
    if settings.demo_mode:
        db = SessionLocal()
        try:
            ensure_demo_workspace(db, reset=False)
            db.commit()
        finally:
            db.close()
    yield


app = FastAPI(
    title="KaamShield AI",
    description="Operations intelligence for MSMEs. NVIDIA Nemotron via Nebius Token Factory explains calculated evidence.",
    version="1.0.0",
    lifespan=lifespan,
)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, lambda r, e: JSONResponse({"detail": "Rate limit exceeded"}, status_code=429))
app.add_middleware(SlowAPIMiddleware)
app.add_middleware(LimitBodyMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(public, prefix="/api")
app.include_router(router, prefix="/api")
