"use client";

import { FormEvent, useState } from "react";
import { api } from "@/lib/api";
import { Badge, ErrorBanner, SuccessBanner } from "@/components/ui";

const PROMPTS = [
  "Which products may run out before the next delivery?",
  "What happens if my largest delayed supplier is delayed by five more days?",
  "Which invoices contain discrepancies or possible duplicates?",
  "Can I afford planned purchases over the next 14 days?",
  "Which operational problem should I solve first?",
];

type CopilotResult = {
  id: string;
  status: string;
  fallback_used: boolean;
  error: string | null;
  model: string;
  attribution: string;
  latency_ms: number | null;
  evidence: Record<string, unknown>;
  response: {
    summary: string;
    identified_risks: { title: string; evidence_refs: string[]; severity: string }[];
    supporting_evidence: string[];
    recommended_actions: { title: string; rationale: string; evidence_refs: string[] }[];
    priority: string;
    estimated_impact: string | null;
    confidence: string;
    data_limitations: string[];
    unanswered_because_missing: string[];
  };
};

export default function CopilotPage() {
  const [question, setQuestion] = useState(PROMPTS[0]);
  const [result, setResult] = useState<CopilotResult | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      setResult(await api<CopilotResult>("/api/copilot", { method: "POST", body: JSON.stringify({ question }) }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Copilot failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">AI operations copilot</h1>
        <p className="text-sm text-mute">
          The backend retrieves stored records and calculated metrics, then asks NVIDIA Nemotron on Nebius Token Factory to explain them.
          The model cannot send emails, change stock, or pay invoices from this screen.
        </p>
      </div>
      {error ? <ErrorBanner message={error} /> : null}
      <form className="card space-y-3" onSubmit={onSubmit}>
        <div className="flex flex-wrap gap-2">
          {PROMPTS.map((item) => (
            <button key={item} className="btn-ghost text-xs" type="button" onClick={() => setQuestion(item)}>
              {item}
            </button>
          ))}
        </div>
        <textarea className="input min-h-28" value={question} onChange={(e) => setQuestion(e.target.value)} required />
        <button className="btn-primary" type="submit" disabled={busy}>
          {busy ? "Retrieving evidence and calling the model…" : "Ask with stored evidence"}
        </button>
      </form>
      {result ? (
        <div className="space-y-4">
          {result.fallback_used ? (
            <ErrorBanner message={`${result.attribution}. Deterministic calculations remain available. ${result.error || ""}`} />
          ) : (
            <SuccessBanner message={`${result.attribution} · ${result.model} · ${result.latency_ms ?? 0} ms`} />
          )}
          <article className="card space-y-3">
            <div className="flex gap-2">
              <Badge level={result.response.priority}>{result.response.priority}</Badge>
              <Badge>{result.response.confidence} confidence</Badge>
            </div>
            <p>{result.response.summary}</p>
            <h2 className="font-medium">Identified risks</h2>
            <ul className="space-y-2 text-sm">
              {result.response.identified_risks.map((risk) => (
                <li key={risk.title}>
                  {risk.title} <span className="text-mute">({risk.severity}; refs {risk.evidence_refs.join(", ") || "none"})</span>
                </li>
              ))}
            </ul>
            <h2 className="font-medium">Recommended actions</h2>
            <ul className="space-y-2 text-sm">
              {result.response.recommended_actions.map((action) => (
                <li key={action.title}>
                  <strong>{action.title}.</strong> {action.rationale}
                </li>
              ))}
            </ul>
            {result.response.estimated_impact ? <p className="text-sm">Impact from supplied calculations: {result.response.estimated_impact}</p> : null}
            <p className="text-xs text-mute">Limitations: {result.response.data_limitations.join(" ") || "none stated"}</p>
            {result.response.unanswered_because_missing.length ? (
              <p className="text-xs text-mute">Missing: {result.response.unanswered_because_missing.join("; ")}</p>
            ) : null}
          </article>
        </div>
      ) : null}
    </div>
  );
}
