"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { api, inr } from "@/lib/api";
import { EmptyState, ErrorBanner, LoadingState, Metric, Badge } from "@/components/ui";
import type { Dashboard } from "@/lib/types";

export default function DashboardPage() {
  const [data, setData] = useState<Dashboard | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api<Dashboard>("/api/dashboard")
      .then(setData)
      .catch((err) => setError(err.message));
  }, []);

  if (error) return <ErrorBanner message={error} />;
  if (!data) return <LoadingState label="Computing dashboard from stored records…" />;
  if (data.empty) {
    return (
      <EmptyState
        title="No operational data yet"
        body="Load the demonstration workspace or import inventory to compute metrics. This screen does not show placeholder numbers."
      />
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Operations overview</h1>
        <p className="text-sm text-mute">
          {data.workspace.name} · {data.workspace.city} · as of {data.as_of}
          {data.workspace.is_demo ? " · labeled synthetic sample data" : ""}
        </p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Metric label="Inventory value" value={inr(data.total_inventory_value)} hint="On-hand × unit cost" />
        <Metric label="Low-stock products" value={String(data.low_stock_products)} hint="At or below reorder threshold" />
        <Metric label="Stockouts in 7 days" value={String(data.predicted_stockouts_7d)} hint="From days of supply" />
        <Metric label="Stockouts in 14 days" value={String(data.predicted_stockouts_14d)} />
        <Metric label="Receivables" value={inr(data.outstanding_receivables)} hint="Open customer invoices" />
        <Metric label="Payables" value={inr(data.outstanding_payables)} hint="Unpaid supplier invoices" />
        <Metric label="Invoice discrepancies" value={String(data.invoice_discrepancies)} hint="Flags for review, not confirmed fraud" />
        <Metric label="Suppliers with delays" value={String(data.suppliers_with_delays)} />
        <Metric
          label="Operational exposure"
          value={inr(data.estimated_operational_exposure)}
          hint="Open delayed POs plus 7-day cost of high-risk SKUs. Estimate, not a booked loss."
        />
        <Metric
          label="14-day cash trough"
          value={inr(data.cash_14d_min_balance)}
          hint={data.cash_14d_shortfalls.length ? `Shortfall dates: ${data.cash_14d_shortfalls.join(", ")}` : "No projected shortfall under stated assumptions"}
        />
      </div>
      <section className="card">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-medium">Open recommended actions</h2>
          <Link className="text-sm text-sky-300 hover:underline" href="/actions">
            Action center
          </Link>
        </div>
        {data.open_actions.length === 0 ? (
          <p className="text-sm text-mute">No open actions. Rebuild from calculated risks in the Action Center if needed.</p>
        ) : (
          <ul className="space-y-2">
            {data.open_actions.map((action) => (
              <li key={action.id} className="flex items-start justify-between gap-3 border-t border-white/5 pt-2 text-sm">
                <span>{action.title}</span>
                <Badge level={action.priority}>{action.priority}</Badge>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
