from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Iterable


@dataclass
class SupplierScore:
    supplier_id: str
    name: str
    observations: int
    on_time_rate: Decimal | None
    avg_actual_lead_days: Decimal | None
    stated_lead_time_days: int
    delayed_open_pos: int
    open_pos: int
    affected_product_ids: list[str]
    reliability_score: Decimal | None
    exposure_inr: Decimal
    explanation: str
    uses_sample_history: bool


def _on_time(promised: date, received: date, grace_days: int = 0) -> bool:
    return received.toordinal() <= promised.toordinal() + grace_days


def reliability_score(
    *,
    on_time_rate: Decimal | None,
    avg_actual: Decimal | None,
    stated: int,
    delayed_open: int,
) -> Decimal | None:
    if on_time_rate is None:
        return None
    score = on_time_rate * Decimal("80")
    if avg_actual is not None and stated > 0:
        overrun = max(Decimal("0"), (avg_actual - Decimal(stated)) / Decimal(stated))
        score -= min(Decimal("20"), overrun * Decimal("20"))
    score -= Decimal(min(delayed_open, 4)) * Decimal("5")
    if score < 0:
        score = Decimal("0")
    if score > 100:
        score = Decimal("100")
    return score.quantize(Decimal("0.1"))


def score_supplier(
    *,
    supplier_id: str,
    name: str,
    stated_lead_time_days: int,
    receipts: Iterable[tuple[date, date]],
    open_pos: Iterable[dict],
    affected_product_ids: list[str],
    exposure_inr: Decimal,
    today: date,
    uses_sample_history: bool,
) -> SupplierScore:
    received_pairs = list(receipts)
    on_time = 0
    lead_sum = 0
    for promised, received in received_pairs:
        if _on_time(promised, received):
            on_time += 1
        lead_sum += max(0, (received - promised).days + stated_lead_time_days)
    n = len(received_pairs)
    on_time_rate = (Decimal(on_time) / Decimal(n)).quantize(Decimal("0.001")) if n else None
    avg_actual = (Decimal(lead_sum) / Decimal(n)).quantize(Decimal("0.1")) if n else None

    open_list = list(open_pos)
    delayed = 0
    for po in open_list:
        promised = po.get("promised_on")
        if promised and promised < today and po.get("status") in {"open", "partial", "delayed"}:
            delayed += 1

    score = reliability_score(
        on_time_rate=on_time_rate,
        avg_actual=avg_actual,
        stated=stated_lead_time_days,
        delayed_open=delayed,
    )
    if n == 0:
        explanation = (
            "No historical receipts are available. Reliability is not estimated. "
            "Stated lead time is used only as an assumption."
        )
    else:
        explanation = (
            f"Based on {n} receipt observation(s): on-time rate {on_time_rate}. "
            "Score uses observed on-time performance, lead-time overrun versus stated lead time, "
            "and currently delayed open purchase orders."
        )
        if uses_sample_history:
            explanation += " History is synthetic sample data, not a real supplier record."

    return SupplierScore(
        supplier_id=supplier_id,
        name=name,
        observations=n,
        on_time_rate=on_time_rate,
        avg_actual_lead_days=avg_actual,
        stated_lead_time_days=stated_lead_time_days,
        delayed_open_pos=delayed,
        open_pos=len(open_list),
        affected_product_ids=affected_product_ids,
        reliability_score=score,
        exposure_inr=exposure_inr,
        explanation=explanation,
        uses_sample_history=uses_sample_history,
    )
