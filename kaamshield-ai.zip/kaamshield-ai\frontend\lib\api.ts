const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("kaamshield_token");
}

export function setToken(token: string) {
  localStorage.setItem("kaamshield_token", token);
}

export function clearToken() {
  localStorage.removeItem("kaamshield_token");
}

export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: HeadersInit = {
    ...(options.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers || {}),
  };
  const response = await fetch(`${API_BASE}${path}`, { ...options, headers });
  if (response.status === 401) {
    clearToken();
    if (typeof window !== "undefined" && !path.includes("/auth/login")) {
      window.location.href = "/";
    }
  }
  if (!response.ok) {
    const err = await response.json().catch(() => ({ detail: response.statusText }));
    throw new Error(typeof err.detail === "string" ? err.detail : JSON.stringify(err.detail));
  }
  return response.json() as Promise<T>;
}

export function inr(value: string | number | null | undefined) {
  if (value === null || value === undefined || value === "") return "—";
  const num = typeof value === "number" ? value : Number(value);
  if (Number.isNaN(num)) return String(value);
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(num);
}

export function riskClass(level: string) {
  if (level === "critical") return "bg-red-500/15 text-red-300 border-red-500/30";
  if (level === "high") return "bg-amber-500/15 text-amber-200 border-amber-500/30";
  if (level === "medium") return "bg-yellow-500/10 text-yellow-200 border-yellow-500/20";
  if (level === "low") return "bg-emerald-500/15 text-emerald-300 border-emerald-500/30";
  return "bg-slate-500/15 text-slate-300 border-slate-500/30";
}
