from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal
from typing import Iterable


ZERO = Decimal("0")


@dataclass
class DailyBalance:
    day: date
    inflow: Decimal
    outflow: Decimal
    balance: Decimal
    notes: list[str] = field(default_factory=list)


@dataclass
class CashProjection:
    opening_cash: Decimal
    horizon_days: int
    daily: list[DailyBalance]
    shortfall_dates: list[date]
    min_balance: Decimal
    min_balance_date: date | None
    assumptions: list[str]


def project_cash(
    *,
    opening_cash: Decimal,
    today: date,
    horizon_days: int,
    inflows: Iterable[dict],
    outflows: Iterable[dict],
) -> CashProjection:
    horizon = max(1, min(horizon_days, 90))
    by_day_in: dict[date, Decimal] = {}
    by_day_out: dict[date, Decimal] = {}
    notes_by_day: dict[date, list[str]] = {}
    assumptions = [
        "Receipts are scheduled on expected_on when provided, otherwise due_on.",
        "An overdue receivable is not assumed to clear unless expected_on is in the horizon.",
        "Supplier invoices unpaid are treated as outflows on due_date.",
        "This is a projection, not a guaranteed cash position.",
    ]

    def _schedule(rows: Iterable[dict], bucket: dict[date, Decimal], kind: str) -> None:
        for row in rows:
            amount = Decimal(str(row.get("amount") or 0))
            if amount <= 0:
                continue
            scheduled: date | None = row.get("scheduled_on")
            overdue = bool(row.get("overdue"))
            note = row.get("note")
            if scheduled is None:
                continue
            if overdue and scheduled < today:
                assumptions.append(
                    f"{kind.title()} {row.get('label', '')} is overdue and is not assumed to arrive unless a future expected date is set."
                )
                continue
            bucket[scheduled] = bucket.get(scheduled, ZERO) + amount
            if note:
                notes_by_day.setdefault(scheduled, []).append(str(note))

    _schedule(inflows, by_day_in, "receipt")
    _schedule(outflows, by_day_out, "payment")

    daily: list[DailyBalance] = []
    balance = Decimal(opening_cash)
    shortfalls: list[date] = []
    min_balance = balance
    min_date: date | None = today

    for offset in range(horizon):
        day = today + timedelta(days=offset)
        inflow = by_day_in.get(day, ZERO)
        outflow = by_day_out.get(day, ZERO)
        balance = (balance + inflow - outflow).quantize(Decimal("0.01"))
        if balance < 0:
            shortfalls.append(day)
        if balance < min_balance:
            min_balance = balance
            min_date = day
        daily.append(
            DailyBalance(
                day=day,
                inflow=inflow.quantize(Decimal("0.01")),
                outflow=outflow.quantize(Decimal("0.01")),
                balance=balance,
                notes=notes_by_day.get(day, []),
            )
        )

    return CashProjection(
        opening_cash=Decimal(opening_cash).quantize(Decimal("0.01")),
        horizon_days=horizon,
        daily=daily,
        shortfall_dates=shortfalls,
        min_balance=min_balance,
        min_balance_date=min_date,
        assumptions=list(dict.fromkeys(assumptions)),
    )
