"use client";

import { FormEvent, useEffect, useState } from "react";
import { api, inr } from "@/lib/api";
import { Badge, EmptyState, ErrorBanner, LoadingState, SuccessBanner } from "@/components/ui";
import type { InvoiceRow, SupplierRow } from "@/lib/types";

export default function InvoicesPage() {
  const [rows, setRows] = useState<InvoiceRow[]>([]);
  const [suppliers, setSuppliers] = useState<SupplierRow[]>([]);
  const [pos, setPos] = useState<{ id: string; po_number: string }[]>([]);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    invoice_number: "",
    supplier_id: "",
    purchase_order_id: "",
    invoice_date: new Date().toISOString().slice(0, 10),
    due_date: new Date().toISOString().slice(0, 10),
    claimed_total: "",
    document_id: "",
    sku: "",
    quantity: "",
    unit_price: "",
  });

  async function load() {
    try {
      const [invoices, supplierRows, poRows] = await Promise.all([
        api<InvoiceRow[]>("/api/invoices"),
        api<SupplierRow[]>("/api/suppliers"),
        api<{ id: string; po_number: string }[]>("/api/purchase-orders"),
      ]);
      setRows(invoices);
      setSuppliers(supplierRows);
      setPos(poRows);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load invoices");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    try {
      const qty = Number(form.quantity);
      const price = Number(form.unit_price);
      await api("/api/invoices", {
        method: "POST",
        body: JSON.stringify({
          invoice_number: form.invoice_number,
          supplier_id: form.supplier_id,
          purchase_order_id: form.purchase_order_id || null,
          invoice_date: form.invoice_date,
          due_date: form.due_date,
          claimed_total: Number(form.claimed_total),
          document_id: form.document_id,
          lines: [{ sku: form.sku, quantity: qty, unit_price: price, line_total: qty * price }],
        }),
      });
      setOk("Invoice stored. Discrepancies are calculated in code, not by the language model.");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Save failed");
    }
  }

  async function onUpload(file: File | null) {
    if (!file) return;
    const data = new FormData();
    data.append("file", file);
    try {
      const result = await api<{ created: number }>("/api/invoices/import-csv", { method: "POST", body: data });
      setOk(`Imported ${result.created} invoice(s).`);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Import failed");
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Invoice and PO auditor</h1>
        <p className="text-sm text-mute">
          Flags quantity, price, total, missing PO, supplier change, repeated numbers, and possible duplicates for review.
          Duplicate flags are not automatic fraud declarations.
        </p>
      </div>
      {error ? <ErrorBanner message={error} /> : null}
      {ok ? <SuccessBanner message={ok} /> : null}
      <div className="flex flex-wrap gap-3">
        <a className="btn-ghost" href="/templates/invoices_template.csv" download>
          Download CSV template
        </a>
        <label className="btn-ghost">
          Import CSV
          <input className="sr-only" type="file" accept=".csv,text/csv" onChange={(e) => onUpload(e.target.files?.[0] || null)} />
        </label>
      </div>
      {loading ? (
        <LoadingState />
      ) : rows.length === 0 ? (
        <EmptyState title="No invoices" body="Enter an invoice or import a CSV to run reconciliation." />
      ) : (
        <div className="space-y-4">
          {rows.map((row) => (
            <article key={row.id} className="card space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="font-medium">{row.invoice_number}</h2>
                  <p className="text-xs text-mute">
                    {row.invoice_date} · due {row.due_date} · claimed {inr(row.claimed_total)}
                    {row.computed_total ? ` · computed ${inr(row.computed_total)}` : ""}
                    {row.sample_data ? " · sample" : ""}
                  </p>
                </div>
                <Badge level={row.flags.length ? "high" : "low"}>{row.flags.length ? `${row.flags.length} flags` : "no flags"}</Badge>
              </div>
              {row.flags.length > 0 ? (
                <div className="table-wrap">
                  <table className="data">
                    <thead>
                      <tr>
                        <th>Code</th>
                        <th>Original</th>
                        <th>Expected</th>
                        <th>Difference</th>
                        <th>Reason</th>
                      </tr>
                    </thead>
                    <tbody>
                      {row.flags.map((flag, idx) => (
                        <tr key={`${flag.code}-${idx}`}>
                          <td className="font-mono text-xs">{flag.code}</td>
                          <td className="font-mono">{flag.original}</td>
                          <td className="font-mono">{flag.expected}</td>
                          <td className="font-mono">{flag.difference}</td>
                          <td className="text-xs text-mute">{flag.reason}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-sm text-mute">No discrepancies versus linked PO arithmetic.</p>
              )}
            </article>
          ))}
        </div>
      )}
      <form className="card grid gap-3 md:grid-cols-3" onSubmit={onSubmit}>
        <h2 className="md:col-span-3 font-medium">Enter invoice</h2>
        <input className="input" placeholder="Invoice number" value={form.invoice_number} onChange={(e) => setForm({ ...form, invoice_number: e.target.value })} required />
        <select className="input" value={form.supplier_id} onChange={(e) => setForm({ ...form, supplier_id: e.target.value })} required>
          <option value="">Supplier</option>
          {suppliers.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
        <select className="input" value={form.purchase_order_id} onChange={(e) => setForm({ ...form, purchase_order_id: e.target.value })}>
          <option value="">No PO (will flag missing PO)</option>
          {pos.map((po) => (
            <option key={po.id} value={po.id}>
              {po.po_number}
            </option>
          ))}
        </select>
        <input className="input" type="date" value={form.invoice_date} onChange={(e) => setForm({ ...form, invoice_date: e.target.value })} required />
        <input className="input" type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} required />
        <input className="input" placeholder="Claimed total" value={form.claimed_total} onChange={(e) => setForm({ ...form, claimed_total: e.target.value })} required />
        <input className="input" placeholder="Document id" value={form.document_id} onChange={(e) => setForm({ ...form, document_id: e.target.value })} />
        <input className="input" placeholder="SKU" value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} required />
        <input className="input" placeholder="Quantity" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} required />
        <input className="input" placeholder="Unit price" value={form.unit_price} onChange={(e) => setForm({ ...form, unit_price: e.target.value })} required />
        <button className="btn-primary md:col-span-3 w-fit" type="submit">
          Reconcile invoice
        </button>
      </form>
    </div>
  );
}
