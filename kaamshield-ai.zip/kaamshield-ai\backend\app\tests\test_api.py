from datetime import date, timedelta
from decimal import Decimal

from app.models.entities import Product, PurchaseOrder, PurchaseOrderLine, Supplier


def test_unauthenticated_inventory_rejected(client):
    response = client.get("/api/inventory")
    assert response.status_code == 401


def test_health(client):
    assert client.get("/api/health").status_code == 200


def test_inventory_create_update_and_stock_risk(client, auth_headers, db_session):
    headers, workspace, _user = auth_headers
    create = client.post(
        "/api/inventory",
        headers=headers,
        json={
            "sku": "SKU-TEST",
            "name": "Test washer",
            "quantity_on_hand": 10,
            "reorder_threshold": 40,
            "avg_daily_demand": 5,
            "lead_time_days": 7,
            "unit_cost": 2.5,
            "selling_price": 5,
            "safety_stock": 5,
        },
    )
    assert create.status_code == 201, create.text
    body = create.json()
    assert body["risk_level"] in {"critical", "high"}
    assert body["expected_stockout_date"] is not None
    product_id = body["id"]
    update = client.patch(
        f"/api/inventory/{product_id}",
        headers=headers,
        json={"quantity_on_hand": 200, "avg_daily_demand": 2},
    )
    assert update.status_code == 200
    assert update.json()["quantity_on_hand"] == "200.000"


def test_invoice_mismatch_via_api(client, auth_headers, db_session):
    headers, workspace, _user = auth_headers
    supplier = Supplier(workspace_id=workspace.id, name="Test Supplier", stated_lead_time_days=7, sample_data=False)
    db_session.add(supplier)
    db_session.flush()
    product = Product(
        workspace_id=workspace.id,
        supplier_id=supplier.id,
        sku="SKU-X",
        name="Widget",
        quantity_on_hand=10,
        avg_daily_demand=1,
        unit_cost=10,
        lead_time_days=5,
        sample_data=False,
    )
    db_session.add(product)
    db_session.flush()
    po = PurchaseOrder(
        workspace_id=workspace.id,
        supplier_id=supplier.id,
        po_number="PO-1",
        status="open",
        ordered_on=date.today(),
        promised_on=date.today() + timedelta(days=5),
        sample_data=False,
    )
    db_session.add(po)
    db_session.flush()
    db_session.add(PurchaseOrderLine(purchase_order_id=po.id, product_id=product.id, quantity=Decimal("10"), unit_price=Decimal("10")))
    db_session.commit()
    created = client.post(
        "/api/invoices",
        headers=headers,
        json={
            "invoice_number": "INV-BAD",
            "supplier_id": supplier.id,
            "purchase_order_id": po.id,
            "invoice_date": date.today().isoformat(),
            "due_date": (date.today() + timedelta(days=7)).isoformat(),
            "claimed_total": 150,
            "lines": [{"sku": "SKU-X", "quantity": 12, "unit_price": 11, "line_total": 132}],
        },
    )
    assert created.status_code == 201
    listed = client.get("/api/invoices", headers=headers)
    flags = listed.json()[0]["flags"]
    codes = {f["code"] for f in flags}
    assert "quantity_mismatch" in codes
    assert "unit_price_mismatch" in codes


def test_cashflow_responds_to_due_dates(client, auth_headers, db_session):
    from app.models.entities import Invoice

    headers, workspace, _user = auth_headers
    supplier = Supplier(workspace_id=workspace.id, name="Cash Supplier", stated_lead_time_days=7, sample_data=False)
    db_session.add(supplier)
    db_session.flush()
    inv = Invoice(
        workspace_id=workspace.id,
        supplier_id=supplier.id,
        invoice_number="INV-CASH",
        invoice_date=date.today(),
        due_date=date.today() + timedelta(days=1),
        status="unpaid",
        claimed_total=Decimal("50000"),
        sample_data=False,
    )
    db_session.add(inv)
    db_session.commit()
    first = client.get("/api/cashflow?horizon=14", headers=headers).json()
    inv.due_date = date.today() + timedelta(days=10)
    db_session.commit()
    second = client.get("/api/cashflow?horizon=14", headers=headers).json()
    assert first["daily"][1]["outflow"] != second["daily"][1]["outflow"] or first["min_balance"] != second["min_balance"]


def test_simulator_delay_changes_via_api(client, auth_headers, db_session):
    headers, workspace, _user = auth_headers
    supplier = Supplier(workspace_id=workspace.id, name="Delay Co", stated_lead_time_days=4, sample_data=False)
    db_session.add(supplier)
    db_session.flush()
    product = Product(
        workspace_id=workspace.id,
        supplier_id=supplier.id,
        sku="SKU-DELAY",
        name="Delayed part",
        quantity_on_hand=20,
        reorder_threshold=40,
        avg_daily_demand=5,
        lead_time_days=4,
        unit_cost=10,
        selling_price=20,
        safety_stock=5,
        sample_data=False,
    )
    db_session.add(product)
    db_session.commit()
    baseline = client.post(
        "/api/simulator",
        headers=headers,
        json={"name": "base", "supplier_delay_days": 0, "focus_supplier_id": supplier.id},
    ).json()
    delayed = client.post(
        "/api/simulator",
        headers=headers,
        json={"name": "delay", "supplier_delay_days": 5, "focus_supplier_id": supplier.id},
    ).json()
    assert delayed["comparison"]["products_affected"]
    assert delayed["simulated_inventory"][0]["suggested_reorder_qty"] != baseline["simulated_inventory"][0]["suggested_reorder_qty"]


def test_copilot_fallback_when_unconfigured(client, auth_headers):
    headers, _ws, _user = auth_headers
    response = client.post("/api/copilot", headers=headers, json={"question": "Which SKU may stock out first?"})
    assert response.status_code == 200
    body = response.json()
    assert body["fallback_used"] is True
    assert "Nemotron" not in body["attribution"] or "fallback" in body["attribution"].lower()
    assert body["response"]["summary"]
