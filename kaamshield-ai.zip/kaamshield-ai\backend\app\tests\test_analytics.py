from datetime import date, timedelta
from decimal import Decimal

from app.analytics.cashflow import project_cash
from app.analytics.reconciliation import compare_invoice_to_po, find_duplicate_candidates
from app.analytics.scenarios import ScenarioAssumptions, compare_scenarios, simulate_inventory
from app.analytics.stockout import (
    days_of_supply,
    estimated_stockout_date,
    suggested_reorder_quantity,
)


def test_days_of_supply_and_stockout_date():
    today = date(2026, 10, 27)
    assert days_of_supply(100, 10) == Decimal("10.00")
    assert estimated_stockout_date(today, 100, 10) == today + timedelta(days=10)
    assert days_of_supply(50, 0) is None
    assert estimated_stockout_date(today, 50, 0) is None
    assert days_of_supply(-5, 10) == Decimal("0.00")


def test_reorder_quantity_avoids_double_counting_pos():
    qty = suggested_reorder_quantity(
        quantity_on_hand=20,
        avg_daily_demand=5,
        lead_time_days=4,
        safety_stock=10,
        pending_po_quantity=15,
    )
    # demand during LT = 20, + safety 10 = 30, minus 20 on hand minus 15 pending = -5 -> 0
    assert qty == Decimal("0.00")
    qty2 = suggested_reorder_quantity(
        quantity_on_hand=5,
        avg_daily_demand=5,
        lead_time_days=4,
        safety_stock=10,
        pending_po_quantity=0,
    )
    assert qty2 == Decimal("25.00")
    assert suggested_reorder_quantity(quantity_on_hand=5, avg_daily_demand=0, lead_time_days=4) is None
    assert suggested_reorder_quantity(quantity_on_hand=5, avg_daily_demand=5, lead_time_days=None) is None


def test_invoice_mismatch_and_totals():
    result = compare_invoice_to_po(
        invoice_id="i1",
        invoice_number="INV-1",
        invoice_supplier_id="s1",
        po_supplier_id="s1",
        claimed_total=120,
        invoice_lines=[{"sku": "A", "quantity": 10, "unit_price": 10, "line_total": 100}],
        po_lines=[{"sku": "A", "quantity": 8, "unit_price": 9}],
    )
    codes = {f.code for f in result.flags}
    assert "quantity_mismatch" in codes
    assert "unit_price_mismatch" in codes
    assert "incorrect_total" in codes
    assert "incorrect_line_total" in codes
    with_gr = compare_invoice_to_po(
        invoice_id="i2",
        invoice_number="INV-2",
        invoice_supplier_id="s1",
        po_supplier_id="s1",
        claimed_total=80,
        invoice_lines=[{"sku": "A", "quantity": 10, "unit_price": 8, "line_total": 80}],
        po_lines=[{"sku": "A", "quantity": 10, "unit_price": 8}],
        receipt_qty_by_sku={"A": 8},
    )
    assert "goods_receipt_quantity_mismatch" in {f.code for f in with_gr.flags}


def test_duplicate_invoice_flags_for_review():
    today = date(2026, 10, 1)
    flags = find_duplicate_candidates(
        [
            {
                "id": "1",
                "supplier_id": "s",
                "invoice_number": "INV-9",
                "claimed_total": 1000,
                "invoice_date": today,
                "document_id": "abc-1",
            },
            {
                "id": "2",
                "supplier_id": "s",
                "invoice_number": "INV-9",
                "claimed_total": 1000,
                "invoice_date": today,
                "document_id": "abc-1",
            },
            {
                "id": "3",
                "supplier_id": "s",
                "invoice_number": "INV-10",
                "claimed_total": 1000,
                "invoice_date": today + timedelta(days=1),
                "document_id": "abc1",
            },
        ]
    )
    codes = {f.code for f in flags}
    assert "repeated_invoice_number" in codes
    assert "possible_duplicate_invoice" in codes


def test_cashflow_projection_and_payment_date_change():
    today = date(2026, 10, 27)
    base = project_cash(
        opening_cash=Decimal("1000"),
        today=today,
        horizon_days=14,
        inflows=[{"amount": 500, "scheduled_on": today + timedelta(days=2), "overdue": False, "label": "AR"}],
        outflows=[{"amount": 800, "scheduled_on": today + timedelta(days=1), "overdue": False, "label": "AP"}],
    )
    assert base.daily[1].balance == Decimal("200.00")
    shifted = project_cash(
        opening_cash=Decimal("1000"),
        today=today,
        horizon_days=14,
        inflows=[{"amount": 500, "scheduled_on": today + timedelta(days=10), "overdue": False, "label": "AR"}],
        outflows=[{"amount": 800, "scheduled_on": today + timedelta(days=1), "overdue": False, "label": "AP"}],
    )
    assert shifted.min_balance < base.min_balance
    overdue = project_cash(
        opening_cash=Decimal("100"),
        today=today,
        horizon_days=7,
        inflows=[{"amount": 5000, "scheduled_on": today - timedelta(days=3), "overdue": True, "label": "late"}],
        outflows=[],
    )
    assert overdue.daily[-1].balance == Decimal("100.00")


def test_scenario_supplier_delay_changes_results():
    today = date(2026, 10, 27)
    products = [
        {
            "id": "p1",
            "sku": "SKU-1",
            "name": "Bolt",
            "quantity_on_hand": 20,
            "reorder_threshold": 40,
            "avg_daily_demand": 5,
            "lead_time_days": 4,
            "unit_cost": 10,
            "selling_price": 20,
            "safety_stock": 5,
            "supplier_id": "sup1",
        }
    ]
    pending = {}
    baseline = simulate_inventory(products=products, pending_by_product=pending, today=today, assumptions=ScenarioAssumptions())
    delayed = simulate_inventory(
        products=products,
        pending_by_product=pending,
        today=today,
        assumptions=ScenarioAssumptions(supplier_delay_days=5, focus_supplier_id="sup1"),
    )
    assert delayed[0].suggested_reorder_qty != baseline[0].suggested_reorder_qty
    cash = project_cash(opening_cash=Decimal("1000"), today=today, horizon_days=14, inflows=[], outflows=[])
    comparison = compare_scenarios(
        baseline=baseline,
        simulated=delayed,
        today=today,
        baseline_cash=cash,
        simulated_cash=cash,
    )
    assert comparison["products_affected"]
