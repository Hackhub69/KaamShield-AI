import { describe, expect, it } from "vitest";
import { riskClass } from "./api";

describe("riskClass", () => {
  it("maps critical to red styling", () => {
    expect(riskClass("critical")).toContain("red");
  });
  it("maps low to green styling", () => {
    expect(riskClass("low")).toContain("emerald");
  });
});
