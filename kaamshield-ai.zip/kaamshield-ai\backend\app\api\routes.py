from __future__ import annotations

import csv
import io
import json
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.ai.provider import InferenceError, NebiusNemotronClient, deterministic_fallback, status_payload
from app.analytics.cashflow import project_cash
from app.analytics.reconciliation import sanitize_csv_cell
from app.analytics.scenarios import (
    ScenarioAssumptions,
    compare_scenarios,
    inflate_outflows,
    serialize_risks,
    shift_inflows,
    simulate_inventory,
)
from app.analytics.stockout import analyze_product
from app.api.deps import get_current_user, get_workspace, owned
from app.core.config import get_settings
from app.core.database import get_db
from app.core.security import create_access_token, verify_password
from app.models.entities import (
    ActionEvent,
    AiAnalysisRecord,
    Invoice,
    InvoiceLine,
    Product,
    PurchaseOrder,
    Receivable,
    RecommendedAction,
    SimulationScenario,
    Supplier,
    User,
    Workspace,
)
from app.schemas import (
    ActionStatusUpdate,
    CopilotQuery,
    DemoLoadRequest,
    InvoiceImport,
    InvoiceImportLine,
    LoginRequest,
    ProductCreate,
    ProductUpdate,
    ScenarioRequest,
    SupplierCreate,
    TokenResponse,
)
from app.services import queries
from app.services.actions import rebuild_actions
from app.services.audit import record
from app.services.demo import DEMO_SLUG, ensure_demo_workspace

router = APIRouter()
public = APIRouter()


@public.get("/health")
def health():
    return {"status": "ok"}


@public.get("/ready")
def ready(db: Session = Depends(get_db)):
    db.execute(select(1))
    settings = get_settings()
    return {
        "status": "ready",
        "database": "ok",
        "ai_configured": settings.ai_configured,
    }


@public.post("/auth/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == payload.email.lower()))
    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    workspace = db.get(Workspace, user.workspace_id)
    token = create_access_token(user_id=user.id, workspace_id=user.workspace_id)
    return TokenResponse(access_token=token, workspace_name=workspace.name if workspace else "", email=user.email)


@router.get("/ai/status")
def ai_status():
    settings = get_settings()
    return status_payload(settings).model_dump()


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), workspace: Workspace = Depends(get_workspace)):
    return queries.dashboard_metrics(db, workspace)


def _product_payload(db: Session, workspace_id: str, product: Product, today: date):
    pending = queries.pending_po_quantities(db, workspace_id).get(product.id, Decimal("0"))
    risk = analyze_product(
        product_id=product.id,
        sku=product.sku,
        name=product.name,
        quantity_on_hand=product.quantity_on_hand,
        reorder_threshold=product.reorder_threshold,
        avg_daily_demand=product.avg_daily_demand,
        lead_time_days=product.lead_time_days,
        unit_cost=product.unit_cost,
        selling_price=product.selling_price,
        safety_stock=product.safety_stock,
        pending_po_quantity=pending,
        today=today,
    )
    return {
        "id": product.id,
        "sku": product.sku,
        "name": product.name,
        "category": product.category,
        "supplier_id": product.supplier_id,
        "quantity_on_hand": str(product.quantity_on_hand),
        "reorder_threshold": str(product.reorder_threshold),
        "safety_stock": str(product.safety_stock),
        "avg_daily_demand": str(product.avg_daily_demand),
        "unit_cost": str(product.unit_cost),
        "selling_price": str(product.selling_price),
        "lead_time_days": product.lead_time_days,
        "days_of_supply": str(risk.days_of_supply) if risk.days_of_supply is not None else None,
        "expected_stockout_date": risk.expected_stockout_date.isoformat() if risk.expected_stockout_date else None,
        "suggested_reorder_qty": str(risk.suggested_reorder_qty) if risk.suggested_reorder_qty is not None else None,
        "demand_during_lead_time": str(risk.demand_during_lead_time) if risk.demand_during_lead_time is not None else None,
        "risk_level": risk.risk_level,
        "explanation": risk.explanation,
        "pending_po_quantity": str(pending),
        "sample_data": product.sample_data,
    }


@router.get("/inventory")
def list_inventory(
    q: str | None = None,
    risk: str | None = None,
    db: Session = Depends(get_db),
    workspace: Workspace = Depends(get_workspace),
):
    today = date.today()
    products = db.scalars(select(Product).where(Product.workspace_id == workspace.id)).all()
    rows = [_product_payload(db, workspace.id, p, today) for p in products]
    if q:
        needle = q.lower()
        rows = [r for r in rows if needle in r["sku"].lower() or needle in r["name"].lower()]
    if risk:
        rows = [r for r in rows if r["risk_level"] == risk]
    return rows


@router.post("/inventory", status_code=201)
def create_inventory(
    payload: ProductCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    workspace: Workspace = Depends(get_workspace),
):
    exists = db.scalar(select(Product).where(Product.workspace_id == workspace.id, Product.sku == payload.sku))
    if exists:
        raise HTTPException(status_code=409, detail="SKU already exists")
    product = Product(workspace_id=workspace.id, sample_data=False, **payload.model_dump())
    db.add(product)
    db.flush()
    record(db, workspace_id=workspace.id, actor_id=user.id, action="create", entity_type="product", entity_id=product.id)
    db.commit()
    db.refresh(product)
    return _product_payload(db, workspace.id, product, date.today())


@router.patch("/inventory/{product_id}")
def update_inventory(
    product_id: str,
    payload: ProductUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    workspace: Workspace = Depends(get_workspace),
):
    product = owned(db, Product, product_id, workspace.id)
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(product, key, value)
    record(db, workspace_id=workspace.id, actor_id=user.id, action="update", entity_type="product", entity_id=product.id)
    db.commit()
    db.refresh(product)
    return _product_payload(db, workspace.id, product, date.today())


@router.get("/suppliers")
def list_suppliers(db: Session = Depends(get_db), workspace: Workspace = Depends(get_workspace)):
    scores = {s.supplier_id: s for s in queries.supplier_scores(db, workspace.id)}
    rows = db.scalars(select(Supplier).where(Supplier.workspace_id == workspace.id)).all()
    payload = []
    for row in rows:
        score = scores.get(row.id)
        payload.append(
            {
                "id": row.id,
                "name": row.name,
                "city": row.city,
                "category": row.category,
                "stated_lead_time_days": row.stated_lead_time_days,
                "sample_data": row.sample_data,
                "on_time_rate": str(score.on_time_rate) if score and score.on_time_rate is not None else None,
                "avg_actual_lead_days": str(score.avg_actual_lead_days) if score and score.avg_actual_lead_days is not None else None,
                "open_pos": score.open_pos if score else 0,
                "delayed_open_pos": score.delayed_open_pos if score else 0,
                "affected_product_ids": score.affected_product_ids if score else [],
                "reliability_score": str(score.reliability_score) if score and score.reliability_score is not None else None,
                "exposure_inr": str(score.exposure_inr) if score else "0",
                "explanation": score.explanation if score else "",
            }
        )
    return payload


@router.post("/suppliers", status_code=201)
def create_supplier(
    payload: SupplierCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    workspace: Workspace = Depends(get_workspace),
):
    row = Supplier(workspace_id=workspace.id, sample_data=False, **payload.model_dump())
    db.add(row)
    db.flush()
    record(db, workspace_id=workspace.id, actor_id=user.id, action="create", entity_type="supplier", entity_id=row.id)
    db.commit()
    db.refresh(row)
    return {"id": row.id, "name": row.name}


@router.get("/purchase-orders")
def list_pos(db: Session = Depends(get_db), workspace: Workspace = Depends(get_workspace)):
    pos = db.scalars(
        select(PurchaseOrder)
        .options(selectinload(PurchaseOrder.lines), selectinload(PurchaseOrder.supplier))
        .where(PurchaseOrder.workspace_id == workspace.id)
    ).all()
    return [
        {
            "id": po.id,
            "po_number": po.po_number,
            "supplier_id": po.supplier_id,
            "supplier_name": po.supplier.name if po.supplier else "",
            "status": po.status,
            "ordered_on": po.ordered_on.isoformat(),
            "promised_on": po.promised_on.isoformat(),
            "received_on": po.received_on.isoformat() if po.received_on else None,
            "sample_data": po.sample_data,
            "lines": [
                {
                    "product_id": line.product_id,
                    "quantity": str(line.quantity),
                    "unit_price": str(line.unit_price),
                }
                for line in po.lines
            ],
        }
        for po in pos
    ]


@router.get("/invoices")
def list_invoices(db: Session = Depends(get_db), workspace: Workspace = Depends(get_workspace)):
    audits = {a.invoice_id: a for a in queries.invoice_audits(db, workspace.id)}
    invoices = db.scalars(select(Invoice).options(selectinload(Invoice.lines)).where(Invoice.workspace_id == workspace.id)).all()
    rows = []
    for inv in invoices:
        audit = audits.get(inv.id)
        rows.append(
            {
                "id": inv.id,
                "invoice_number": inv.invoice_number,
                "supplier_id": inv.supplier_id,
                "purchase_order_id": inv.purchase_order_id,
                "invoice_date": inv.invoice_date.isoformat(),
                "due_date": inv.due_date.isoformat(),
                "status": inv.status,
                "claimed_total": str(inv.claimed_total),
                "computed_total": str(audit.computed_total) if audit else None,
                "sample_data": inv.sample_data,
                "flags": [
                    {
                        "code": f.code,
                        "reason": f.reason,
                        "field": f.field,
                        "original": f.original,
                        "expected": f.expected,
                        "difference": f.difference,
                        "related_invoice_id": f.related_invoice_id,
                    }
                    for f in (audit.flags if audit else [])
                ],
                "lines": [
                    {
                        "sku": line.sku,
                        "quantity": str(line.quantity),
                        "unit_price": str(line.unit_price),
                        "line_total": str(line.line_total),
                    }
                    for line in inv.lines
                ],
            }
        )
    return rows


def _csv_date(value) -> date:
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    text = str(value)[:10]
    return date.fromisoformat(text)


def _csv_decimal(value) -> Decimal:
    if value in (None, ""):
        return Decimal("0")
    return Decimal(str(value))


def _save_invoice(db: Session, workspace_id: str, payload: InvoiceImport) -> Invoice:
    inv = Invoice(
        workspace_id=workspace_id,
        supplier_id=payload.supplier_id,
        purchase_order_id=payload.purchase_order_id,
        invoice_number=payload.invoice_number,
        invoice_date=payload.invoice_date,
        due_date=payload.due_date,
        claimed_total=payload.claimed_total,
        document_id=payload.document_id,
        sample_data=False,
    )
    db.add(inv)
    db.flush()
    for line in payload.lines:
        product = db.scalar(select(Product).where(Product.workspace_id == workspace_id, Product.sku == line.sku))
        qty = line.quantity
        price = line.unit_price
        total = line.line_total if line.line_total is not None else (qty * price)
        db.add(
            InvoiceLine(
                invoice_id=inv.id,
                product_id=product.id if product else None,
                sku=line.sku,
                description=line.description,
                quantity=qty,
                unit_price=price,
                line_total=total,
            )
        )
    return inv


@router.post("/invoices", status_code=201)
def create_invoice(
    payload: InvoiceImport,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    workspace: Workspace = Depends(get_workspace),
):
    if payload.purchase_order_id:
        owned(db, PurchaseOrder, payload.purchase_order_id, workspace.id)
    owned(db, Supplier, payload.supplier_id, workspace.id)
    inv = _save_invoice(db, workspace.id, payload)
    record(db, workspace_id=workspace.id, actor_id=user.id, action="create", entity_type="invoice", entity_id=inv.id)
    db.commit()
    return {"id": inv.id}


@router.post("/invoices/import-csv")
async def import_invoices_csv(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    workspace: Workspace = Depends(get_workspace),
):
    settings = get_settings()
    content_type = (file.content_type or "").split(";")[0].strip()
    filename = (file.filename or "").lower()
    if content_type not in {"", "text/csv", "application/vnd.ms-excel", "application/csv", "text/plain", "application/octet-stream"} and not filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV uploads are accepted")
    raw = await file.read()
    if len(raw) > settings.max_upload_bytes:
        raise HTTPException(status_code=400, detail="File too large")
    import pandas as pd

    try:
        frame = pd.read_csv(io.BytesIO(raw))
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail="Could not parse CSV") from exc
    created = 0
    grouped: dict[str, list[dict]] = {}
    for row in frame.fillna("").to_dict(orient="records"):
        grouped.setdefault(str(row.get("invoice_number", "")), []).append(row)
    for number, rows in grouped.items():
        if not number:
            continue
        first = rows[0]
        supplier = db.scalar(select(Supplier).where(Supplier.workspace_id == workspace.id, Supplier.name == first.get("supplier_name")))
        if not supplier and first.get("supplier_id"):
            supplier = db.get(Supplier, first["supplier_id"])
        if not supplier or supplier.workspace_id != workspace.id:
            continue
        po = None
        if first.get("po_number"):
            po = db.scalar(select(PurchaseOrder).where(PurchaseOrder.workspace_id == workspace.id, PurchaseOrder.po_number == first["po_number"]))
        lines = []
        for row in rows:
            try:
                qty = Decimal(str(row.get("quantity") or "0"))
                price = Decimal(str(row.get("unit_price") or "0"))
                total = Decimal(str(row.get("line_total") or (qty * price)))
            except (InvalidOperation, TypeError) as exc:
                raise HTTPException(status_code=400, detail="Invalid numeric value in CSV") from exc
            lines.append(InvoiceImportLine(sku=row.get("sku") or "", quantity=qty, unit_price=price, line_total=total))
        payload = InvoiceImport(
            invoice_number=number,
            supplier_id=supplier.id,
            purchase_order_id=po.id if po else None,
            invoice_date=_csv_date(first.get("invoice_date")),
            due_date=_csv_date(first.get("due_date")),
            claimed_total=_csv_decimal(first.get("claimed_total")),
            document_id=str(first.get("document_id") or ""),
            lines=lines,
        )
        _save_invoice(db, workspace.id, payload)
        created += 1
    record(db, workspace_id=workspace.id, actor_id=user.id, action="import", entity_type="invoice", details=f"rows={created}")
    db.commit()
    return {"created": created}


@router.get("/invoices/export.csv")
def export_invoice_flags(db: Session = Depends(get_db), workspace: Workspace = Depends(get_workspace)):
    audits = queries.invoice_audits(db, workspace.id)
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["invoice_id", "invoice_number", "code", "reason", "original", "expected", "difference"])
    for audit in audits:
        for flag in audit.flags:
            writer.writerow(
                [
                    sanitize_csv_cell(flag.invoice_id or ""),
                    sanitize_csv_cell(audit.invoice_number),
                    sanitize_csv_cell(flag.code),
                    sanitize_csv_cell(flag.reason),
                    sanitize_csv_cell(flag.original),
                    sanitize_csv_cell(flag.expected),
                    sanitize_csv_cell(flag.difference),
                ]
            )
    return {"csv": buffer.getvalue()}


@router.get("/cashflow")
def cashflow(horizon: int = Query(default=14, ge=7, le=30), db: Session = Depends(get_db), workspace: Workspace = Depends(get_workspace)):
    projection = queries.cash_projection(db, workspace, horizon)
    recs = db.scalars(select(Receivable).where(Receivable.workspace_id == workspace.id, Receivable.status == "open")).all()
    overdue = [
        {
            "id": r.id,
            "customer_name": r.customer_name,
            "invoice_number": r.invoice_number,
            "amount": str(r.amount),
            "due_on": r.due_on.isoformat(),
            "assumption": r.payment_assumption,
        }
        for r in recs
        if r.due_on < date.today()
    ]
    return {
        "opening_cash": str(projection.opening_cash),
        "horizon_days": projection.horizon_days,
        "min_balance": str(projection.min_balance),
        "min_balance_date": projection.min_balance_date.isoformat() if projection.min_balance_date else None,
        "shortfall_dates": [d.isoformat() for d in projection.shortfall_dates],
        "assumptions": projection.assumptions,
        "daily": [
            {
                "day": d.day.isoformat(),
                "inflow": str(d.inflow),
                "outflow": str(d.outflow),
                "balance": str(d.balance),
                "notes": d.notes,
            }
            for d in projection.daily
        ],
        "overdue_receivables": overdue,
    }


@router.post("/simulator")
def run_simulator(
    payload: ScenarioRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    workspace: Workspace = Depends(get_workspace),
):
    today = date.today()
    products = db.scalars(select(Product).where(Product.workspace_id == workspace.id)).all()
    product_dicts = [
        {
            "id": p.id,
            "sku": p.sku,
            "name": p.name,
            "quantity_on_hand": p.quantity_on_hand,
            "reorder_threshold": p.reorder_threshold,
            "avg_daily_demand": p.avg_daily_demand,
            "lead_time_days": p.lead_time_days,
            "unit_cost": p.unit_cost,
            "selling_price": p.selling_price,
            "safety_stock": p.safety_stock,
            "supplier_id": p.supplier_id,
        }
        for p in products
    ]
    pending = queries.pending_po_quantities(db, workspace.id)
    assumptions = ScenarioAssumptions(
        supplier_delay_days=payload.supplier_delay_days,
        demand_change_pct=payload.demand_change_pct,
        supplier_price_increase_pct=payload.supplier_price_increase_pct,
        customer_payment_delay_days=payload.customer_payment_delay_days,
        available_working_capital=payload.available_working_capital,
        alternative_lead_time_days=payload.alternative_lead_time_days,
        proposed_purchase_qty=payload.proposed_purchase_qty,
        proposed_purchase_product_id=payload.proposed_purchase_product_id,
        focus_supplier_id=payload.focus_supplier_id,
    )
    baseline_inv = simulate_inventory(products=product_dicts, pending_by_product=pending, today=today, assumptions=ScenarioAssumptions())
    sim_inv = simulate_inventory(products=product_dicts, pending_by_product=pending, today=today, assumptions=assumptions)
    inflows, outflows = queries.cash_inputs(db, workspace.id, today)
    opening = payload.available_working_capital if payload.available_working_capital is not None else workspace.opening_cash
    baseline_cash = project_cash(opening_cash=workspace.opening_cash, today=today, horizon_days=payload.horizon_days, inflows=inflows, outflows=outflows)
    sim_cash = project_cash(
        opening_cash=opening,
        today=today,
        horizon_days=payload.horizon_days,
        inflows=shift_inflows(inflows, payload.customer_payment_delay_days),
        outflows=inflate_outflows(outflows, payload.supplier_price_increase_pct, payload.focus_supplier_id),
    )
    comparison = compare_scenarios(
        baseline=baseline_inv,
        simulated=sim_inv,
        today=today,
        baseline_cash=baseline_cash,
        simulated_cash=sim_cash,
    )
    mitigations = []
    for item in sim_inv:
        if item.risk_level in {"critical", "high"} and item.suggested_reorder_qty and item.suggested_reorder_qty > 0:
            mitigations.append(
                {
                    "product_id": item.product_id,
                    "sku": item.sku,
                    "action": "Place replenishment covering lead-time demand plus safety stock, without double-counting pending POs.",
                    "suggested_qty": str(item.suggested_reorder_qty),
                    "estimated_buy_inr": str((item.suggested_reorder_qty * item.unit_cost).quantize(Decimal("0.01"))),
                }
            )
    result = {
        "assumptions": payload.model_dump(mode="json"),
        "baseline_inventory": serialize_risks(baseline_inv),
        "simulated_inventory": serialize_risks(sim_inv),
        "baseline_cash": {
            "daily": [{"day": d.day.isoformat(), "balance": str(d.balance)} for d in baseline_cash.daily],
            "shortfall_dates": [d.isoformat() for d in baseline_cash.shortfall_dates],
            "min_balance": str(baseline_cash.min_balance),
        },
        "simulated_cash": {
            "daily": [{"day": d.day.isoformat(), "balance": str(d.balance)} for d in sim_cash.daily],
            "shortfall_dates": [d.isoformat() for d in sim_cash.shortfall_dates],
            "min_balance": str(sim_cash.min_balance),
        },
        "comparison": comparison,
        "mitigations": mitigations[:8],
        "uncertainty": comparison["uncertainty"],
    }
    scenario = SimulationScenario(
        workspace_id=workspace.id,
        name=payload.name,
        assumptions_json=json.dumps(payload.model_dump(mode="json")),
        results_json=json.dumps({"comparison": comparison, "mitigations": mitigations[:8]}),
    )
    db.add(scenario)
    db.flush()
    record(db, workspace_id=workspace.id, actor_id=user.id, action="simulate", entity_type="scenario", entity_id=scenario.id)
    db.commit()
    result["scenario_id"] = scenario.id
    return result


@router.post("/copilot")
def copilot(
    payload: CopilotQuery,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    workspace: Workspace = Depends(get_workspace),
):
    settings = get_settings()
    evidence = queries.evidence_package(db, workspace, extra={"operator_question": payload.question})
    client = NebiusNemotronClient(settings)
    fallback = False
    error = None
    try:
        result = client.complete(payload.question, evidence)
        status_name = "connected"
    except InferenceError as exc:
        result = deterministic_fallback(payload.question, evidence)
        result.status = exc.status
        fallback = True
        error = str(exc)
        status_name = exc.status

    record_row = AiAnalysisRecord(
        workspace_id=workspace.id,
        query=payload.question,
        evidence_json=json.dumps(evidence),
        response_json=result.response.model_dump_json(),
        model_id=result.model_id,
        provider_status=status_name,
        latency_ms=result.latency_ms,
        prompt_tokens=result.prompt_tokens,
        completion_tokens=result.completion_tokens,
        fallback_used=fallback or result.fallback_used,
    )
    db.add(record_row)
    db.commit()
    db.refresh(record_row)
    return {
        "id": record_row.id,
        "status": status_name,
        "fallback_used": record_row.fallback_used,
        "error": error,
        "model": result.model_id,
        "attribution": "NVIDIA Nemotron via Nebius Token Factory" if not record_row.fallback_used else "Deterministic fallback (not Nemotron)",
        "latency_ms": result.latency_ms,
        "prompt_tokens": result.prompt_tokens,
        "completion_tokens": result.completion_tokens,
        "evidence": evidence,
        "response": result.response.model_dump(),
    }


@router.get("/ai/analyses")
def list_analyses(db: Session = Depends(get_db), workspace: Workspace = Depends(get_workspace)):
    rows = db.scalars(
        select(AiAnalysisRecord)
        .where(AiAnalysisRecord.workspace_id == workspace.id)
        .order_by(AiAnalysisRecord.created_at.desc())
        .limit(20)
    ).all()
    return [
        {
            "id": row.id,
            "query": row.query,
            "model_id": row.model_id,
            "provider_status": row.provider_status,
            "fallback_used": row.fallback_used,
            "latency_ms": row.latency_ms,
            "created_at": row.created_at.isoformat() if row.created_at else None,
            "response": json.loads(row.response_json or "{}"),
            "evidence": json.loads(row.evidence_json or "{}"),
        }
        for row in rows
    ]


@router.get("/actions")
def list_actions(db: Session = Depends(get_db), workspace: Workspace = Depends(get_workspace)):
    rows = db.scalars(
        select(RecommendedAction)
        .options(selectinload(RecommendedAction.events))
        .where(RecommendedAction.workspace_id == workspace.id)
        .order_by(RecommendedAction.created_at.desc())
    ).all()
    return [
        {
            "id": a.id,
            "title": a.title,
            "why": a.why,
            "domain": a.domain,
            "record_ids": json.loads(a.record_ids or "[]"),
            "priority": a.priority,
            "deadline": a.deadline.isoformat() if a.deadline else None,
            "expected_benefit": a.expected_benefit,
            "requires_approval": a.requires_approval,
            "status": a.status,
            "events": [
                {
                    "actor": e.actor,
                    "from_status": e.from_status,
                    "to_status": e.to_status,
                    "note": e.note,
                    "created_at": e.created_at.isoformat() if e.created_at else None,
                }
                for e in a.events
            ],
        }
        for a in rows
    ]


@router.post("/actions/rebuild")
def rebuild(db: Session = Depends(get_db), user: User = Depends(get_current_user), workspace: Workspace = Depends(get_workspace)):
    created = rebuild_actions(db, workspace)
    record(db, workspace_id=workspace.id, actor_id=user.id, action="rebuild", entity_type="action")
    db.commit()
    return {"created": len(created)}


@router.post("/actions/{action_id}/status")
def update_action(
    action_id: str,
    payload: ActionStatusUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    workspace: Workspace = Depends(get_workspace),
):
    if payload.status not in {"open", "reviewed", "dismissed", "completed"}:
        raise HTTPException(status_code=400, detail="Invalid status")
    action = owned(db, RecommendedAction, action_id, workspace.id)
    previous = action.status
    action.status = payload.status
    db.add(
        ActionEvent(
            action_id=action.id,
            actor=user.email,
            from_status=previous,
            to_status=payload.status,
            note=payload.note,
        )
    )
    record(db, workspace_id=workspace.id, actor_id=user.id, action="status", entity_type="action", entity_id=action.id, details=payload.status)
    db.commit()
    return {"id": action.id, "status": action.status}


@router.post("/demo/load")
def load_demo(
    payload: DemoLoadRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    workspace: Workspace = Depends(get_workspace),
):
    if workspace.slug != DEMO_SLUG:
        raise HTTPException(status_code=403, detail="Demo loader is restricted to the demonstration workspace")
    has_products = db.scalar(select(Product).where(Product.workspace_id == workspace.id))
    if has_products and not payload.confirm_overwrite:
        raise HTTPException(status_code=409, detail="Demo data already exists. Set confirm_overwrite=true to reset.")
    ensure_demo_workspace(db, reset=True)
    record(db, workspace_id=workspace.id, actor_id=user.id, action="reset_demo", entity_type="workspace")
    db.commit()
    return {"status": "loaded", "workspace": DEMO_SLUG}


@router.get("/me")
def me(user: User = Depends(get_current_user), workspace: Workspace = Depends(get_workspace)):
    settings = get_settings()
    return {
        "email": user.email,
        "name": user.full_name,
        "workspace": workspace.name,
        "is_demo": workspace.is_demo,
        "ai": status_payload(settings).model_dump(),
    }
