# KaamShield AI — 3-Minute Demo Video Script
## NVIDIA × Nebius Global AI Hackathon (Best Apps & Agents Track)

**Target Video Duration:** 2 minutes 50 seconds  
**Presenter:** Founder & Full-Stack AI Engineer  
**Screen Recording:** Live KaamShield AI application running locally on `http://localhost:3000`

---

### [0:00 - 0:30] Problem Statement & Context
*(Visual: Quick slide of an Indian industrial cluster in Pune/Faridabad, transitioning to KaamShield AI Dashboard)*

"Hello judges! Over 63 million MSMEs form the backbone of global manufacturing. But 82% of small factory failures stem from unexpected operational shocks discovered too late:
- A steel supplier delivers 5 days late, halting CNC machines.
- Invoices contain hidden price creep or duplicate billings.
- Cash-flow gaps trigger missed payroll.

Existing ERPs are passive ledgers; they don't predict failure. Today, we built **KaamShield AI** — a proactive operations intelligence platform pairing deterministic risk engines with **NVIDIA Nemotron 3** reasoning hosted on **Nebius Token Factory**."

---

### [0:30 - 1:15] Flagship Feature: The Business Failure Simulator
*(Visual: Switch to 'Business Failure Simulator' tab)*

"Let's look at our flagship feature: the **Business Failure Simulator**.
Instead of discovering bottlenecks after production halts, factory owners can stress-test assumptions before placing purchase orders:

*(Action: Drag 'Supplier Delay' slider to +5 Days)*
- Watch what happens in real time: as Bharat Steels is delayed 5 days, our deterministic engine calculates that EN19 Alloy Steel will run out in 2.8 days.
- That's **₹86,400 in capacity revenue at risk**.

*(Action: Drag 'Demand Shift' slider to +20% and 'Customer Payment Delay' to +7 Days)*
- Instantly, the system computes our working capital impact: a **liquidity deficit of ₹1,45,000 on November 7th**.
- Look below: KaamShield gives the **cheapest feasible mitigation**: 'Air-freight an expedited batch of 35 units (~₹12,000) or offer a 2% early-payment incentive to Bajaj Auto to unlock working capital.'
- Every number is derived from code and verifiable formulas — no hallucinations."

---

### [1:15 - 2:00] NVIDIA Nemotron on Nebius Token Factory Co-pilot
*(Visual: Switch to 'AI Copilot' tab)*

"Now, how does AI supercharge this?
*(Action: Click prompt chip 'What happens if Bharat Steels is delayed 5 days?')*

Watch the response:
- Our FastAPI backend first constructs an **Operational Evidence Package** containing verified inventory, PO lead times, and unpaid invoices from our database.
- It passes this evidence to **NVIDIA Nemotron 3** via the **Nebius Token Factory** OpenAI-compatible API.
- Nemotron returns a structured executive assessment citing exact SKU IDs (`STL-EN19-40`) and invoice numbers (`BS-INV-8491`).
- Notice the transparency: we include latency (340ms), token usage, and even an 'Inspect Raw Evidence' drawer showing the exact JSON passed to the model."

---

### [2:00 - 2:30] Invoice & PO Auditor + Cash Flow Engine
*(Visual: Switch to 'Invoice Auditor' tab)*

"Next, our **Invoice & PO Auditor**. Small businesses lose up to 4% of turnover to billing anomalies.
- Here, Invoice `#BS-INV-8491` is automatically flagged: the vendor charged ₹315 per unit for steel rod against an agreed PO price of ₹285.
- Notice Invoice `#MPF-2026-441`: our multi-attribute matcher detected an identical ₹24,800 invoice submitted twice within 30 days — blocking a duplicate payment!

*(Visual: Quick switch to 'Cash Flow' tab)*
- Our 14-day cash-flow projection combines verified receivables, payroll, and power bills, clearly pinpointing any upcoming deficit dates."

---

### [2:30 - 2:50] Action Center & Summary
*(Visual: Switch to 'Action Center' tab)*

"Finally, the **Action Center** consolidates these insights into prioritized, actionable tasks:
- One click to dispute the price variance or approve emergency replenishment.
- All actions maintain an immutable audit trail.
- And if the AI endpoint ever loses connection, our deterministic engine continues uninterrupted with zero downtime."

---

### [2:50 - 3:00] Closing
"KaamShield AI delivers real resilience to real manufacturers. Open-source, production-ready, grounded in deterministic truth, and supercharged by NVIDIA Nemotron on Nebius. Thank you!"
