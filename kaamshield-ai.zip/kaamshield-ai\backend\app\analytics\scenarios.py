from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, timedelta
from decimal import Decimal
from typing import Any

from app.analytics.cashflow import CashProjection, project_cash
from app.analytics.stockout import InventoryRisk, analyze_product, margin_at_risk


@dataclass
class ScenarioAssumptions:
    supplier_delay_days: int = 0
    demand_change_pct: float = 0.0
    supplier_price_increase_pct: float = 0.0
    customer_payment_delay_days: int = 0
    available_working_capital: Decimal | None = None
    alternative_lead_time_days: int | None = None
    proposed_purchase_qty: Decimal = Decimal("0")
    proposed_purchase_product_id: str | None = None
    focus_supplier_id: str | None = None


def _apply_demand(demand: Decimal, pct: float) -> Decimal:
    factor = Decimal(str(1.0 + (pct / 100.0)))
    if factor < 0:
        factor = Decimal("0")
    return (demand * factor).quantize(Decimal("0.0001"))


def simulate_inventory(
    *,
    products: list[dict[str, Any]],
    pending_by_product: dict[str, Decimal],
    today: date,
    assumptions: ScenarioAssumptions,
) -> list[InventoryRisk]:
    results: list[InventoryRisk] = []
    for product in products:
        demand = _apply_demand(Decimal(str(product["avg_daily_demand"])), assumptions.demand_change_pct)
        lead = product.get("lead_time_days")
        if assumptions.focus_supplier_id and product.get("supplier_id") == assumptions.focus_supplier_id:
            if lead is not None:
                lead = int(lead) + max(0, assumptions.supplier_delay_days)
            if assumptions.alternative_lead_time_days is not None:
                lead = assumptions.alternative_lead_time_days
        elif assumptions.focus_supplier_id is None and lead is not None:
            lead = int(lead) + max(0, assumptions.supplier_delay_days)
        pending = pending_by_product.get(product["id"], Decimal("0"))
        extra = Decimal("0")
        if assumptions.proposed_purchase_product_id == product["id"]:
            extra = Decimal(str(assumptions.proposed_purchase_qty or 0))
        results.append(
            analyze_product(
                product_id=product["id"],
                sku=product["sku"],
                name=product["name"],
                quantity_on_hand=product["quantity_on_hand"],
                reorder_threshold=product["reorder_threshold"],
                avg_daily_demand=demand,
                lead_time_days=lead,
                unit_cost=product["unit_cost"],
                selling_price=product.get("selling_price", 0),
                safety_stock=product.get("safety_stock", 0),
                pending_po_quantity=pending + extra,
                today=today,
            )
        )
    return results


def stockout_days(risk: InventoryRisk, today: date, horizon: int = 30) -> int:
    if risk.expected_stockout_date is None:
        return 0
    days = (risk.expected_stockout_date - today).days
    if days >= horizon:
        return 0
    return max(0, horizon - max(days, 0))


def compare_scenarios(
    *,
    baseline: list[InventoryRisk],
    simulated: list[InventoryRisk],
    today: date,
    baseline_cash: CashProjection,
    simulated_cash: CashProjection,
) -> dict[str, Any]:
    base_map = {item.product_id: item for item in baseline}
    affected = []
    revenue_at_risk = Decimal("0")
    for item in simulated:
        prior = base_map.get(item.product_id)
        if not prior:
            continue
        changed = (
            prior.expected_stockout_date != item.expected_stockout_date
            or prior.risk_level != item.risk_level
            or prior.suggested_reorder_qty != item.suggested_reorder_qty
        )
        extra_stockout = stockout_days(item, today) - stockout_days(prior, today)
        extra_margin = margin_at_risk(item.avg_daily_demand, item.selling_price, item.unit_cost, extra_stockout)
        if extra_margin > 0:
            revenue_at_risk += extra_margin
        if changed:
            affected.append(
                {
                    "product_id": item.product_id,
                    "sku": item.sku,
                    "name": item.name,
                    "baseline_stockout": prior.expected_stockout_date.isoformat() if prior.expected_stockout_date else None,
                    "simulated_stockout": item.expected_stockout_date.isoformat() if item.expected_stockout_date else None,
                    "baseline_risk": prior.risk_level,
                    "simulated_risk": item.risk_level,
                    "margin_at_risk_inr": str(extra_margin),
                }
            )

    additional_cash = Decimal("0")
    if simulated_cash.min_balance < 0:
        additional_cash = (-simulated_cash.min_balance).quantize(Decimal("0.01"))

    return {
        "products_affected": affected,
        "estimated_margin_at_risk_inr": str(revenue_at_risk.quantize(Decimal("0.01"))),
        "additional_cash_required_inr": str(additional_cash),
        "baseline_shortfall_dates": [d.isoformat() for d in baseline_cash.shortfall_dates],
        "simulated_shortfall_dates": [d.isoformat() for d in simulated_cash.shortfall_dates],
        "uncertainty": (
            "Margin at risk is an estimate of contribution margin that could be missed if demand "
            "continues at the modeled rate during extra stockout days. It is not a guaranteed loss."
        ),
    }


def shift_inflows(inflows: list[dict], delay_days: int) -> list[dict]:
    if delay_days <= 0:
        return inflows
    shifted = []
    for row in inflows:
        copy = dict(row)
        scheduled = copy.get("scheduled_on")
        if scheduled:
            copy["scheduled_on"] = scheduled + timedelta(days=delay_days)
            copy["note"] = (copy.get("note") or "") + f" Payment delay assumption +{delay_days} days."
        shifted.append(copy)
    return shifted


def inflate_outflows(outflows: list[dict], price_increase_pct: float, supplier_id: str | None) -> list[dict]:
    if price_increase_pct == 0:
        return outflows
    factor = Decimal(str(1.0 + price_increase_pct / 100.0))
    inflated = []
    for row in outflows:
        copy = dict(row)
        if supplier_id is None or copy.get("supplier_id") == supplier_id:
            copy["amount"] = (Decimal(str(copy["amount"])) * factor).quantize(Decimal("0.01"))
            copy["note"] = (copy.get("note") or "") + f" Price increase +{price_increase_pct}%."
        inflated.append(copy)
    return inflated


def serialize_risks(items: list[InventoryRisk]) -> list[dict]:
    payload = []
    for item in items:
        row = asdict(item)
        for key, value in list(row.items()):
            if isinstance(value, Decimal):
                row[key] = str(value)
            elif isinstance(value, date):
                row[key] = value.isoformat()
        payload.append(row)
    return payload
