"use client";

import { FormEvent, useEffect, useState } from "react";
import { api, inr } from "@/lib/api";
import { Badge, EmptyState, ErrorBanner, LoadingState, SuccessBanner } from "@/components/ui";
import type { SupplierRow } from "@/lib/types";

export default function SuppliersPage() {
  const [rows, setRows] = useState<SupplierRow[]>([]);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: "", city: "", category: "", stated_lead_time_days: "7" });

  async function load() {
    try {
      setRows(await api<SupplierRow[]>("/api/suppliers"));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load suppliers");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    try {
      await api("/api/suppliers", {
        method: "POST",
        body: JSON.stringify({ ...form, stated_lead_time_days: Number(form.stated_lead_time_days) }),
      });
      setOk("Supplier created. Reliability score appears only after receipt history exists.");
      setForm({ name: "", city: "", category: "", stated_lead_time_days: "7" });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Create failed");
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Supplier risk monitor</h1>
        <p className="text-sm text-mute">
          Reliability uses observed on-time receipts when they exist. Histories in the demo workspace are synthetic and labeled.
          Real businesses are never given fabricated delivery histories.
        </p>
      </div>
      {error ? <ErrorBanner message={error} /> : null}
      {ok ? <SuccessBanner message={ok} /> : null}
      {loading ? (
        <LoadingState />
      ) : rows.length === 0 ? (
        <EmptyState title="No suppliers" body="Add a supplier to start tracking purchase orders and delays." />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {rows.map((row) => (
            <article key={row.id} className="card space-y-2">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="font-medium">{row.name}</h2>
                  <p className="text-xs text-mute">
                    {row.city} · {row.category}
                    {row.sample_data ? " · synthetic sample" : ""}
                  </p>
                </div>
                {row.delayed_open_pos > 0 ? <Badge level="high">{row.delayed_open_pos} delayed PO</Badge> : <Badge level="low">on track</Badge>}
              </div>
              <dl className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <dt className="text-mute">Stated lead time</dt>
                  <dd className="font-mono">{row.stated_lead_time_days}d</dd>
                </div>
                <div>
                  <dt className="text-mute">Observed avg lead</dt>
                  <dd className="font-mono">{row.avg_actual_lead_days ?? "insufficient history"}</dd>
                </div>
                <div>
                  <dt className="text-mute">On-time rate</dt>
                  <dd className="font-mono">{row.on_time_rate ?? "n/a"}</dd>
                </div>
                <div>
                  <dt className="text-mute">Reliability</dt>
                  <dd className="font-mono">{row.reliability_score ?? "not scored"}</dd>
                </div>
                <div>
                  <dt className="text-mute">Open POs</dt>
                  <dd className="font-mono">{row.open_pos}</dd>
                </div>
                <div>
                  <dt className="text-mute">Open PO exposure</dt>
                  <dd className="font-mono">{inr(row.exposure_inr)}</dd>
                </div>
              </dl>
              <p className="text-xs text-mute">{row.explanation}</p>
            </article>
          ))}
        </div>
      )}
      <form className="card grid gap-3 md:grid-cols-4" onSubmit={onSubmit}>
        <h2 className="md:col-span-4 font-medium">Add supplier</h2>
        <input className="input" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <input className="input" placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
        <input className="input" placeholder="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
        <input
          className="input"
          type="number"
          min={0}
          placeholder="Stated lead time"
          value={form.stated_lead_time_days}
          onChange={(e) => setForm({ ...form, stated_lead_time_days: e.target.value })}
        />
        <button className="btn-primary md:col-span-4 w-fit" type="submit">
          Create supplier
        </button>
      </form>
    </div>
  );
}
